<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:83:"E:\shixun\thinkphp5\public/../application/index\view\personalscomment\scomment.html";i:1546523401;s:48:"../application/index/view/common/center_top.html";i:1545112582;s:53:"../application/index/view/common/center_leftmenu.html";i:1546481110;s:49:"../application/index/view/common/common_foot.html";i:1544954783;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>淘书街：个人中心 - 我的求购留言</title>
		<link rel="stylesheet" href="../../../../static/css/front/personal.css" />
		<link rel="stylesheet" href="../../../../static/css/front/personal_sale.css" />
		<link rel="stylesheet" href="../../../../static/font/css/font-awesome.min.css" />
		<link rel="shortcut icon" href="../../../../static/img/shu.ico" />
	</head>
	<script type="text/javascript" src="../../../../static/js/front/jquery.min.js" ></script>
	<body>
		<div class="top">
			<div class="logo">
				<div class="img"><a href="?"><img src="../../../../static/img/taoshujie.png" /></a></div>
				<div class="txt"><?php echo session('username'); ?>-个人中心</div>
				<div class="right">
					<a href="/index/index/index">首页</a> <span class="shu">|</span>
					<a href="/index/sale/showAllSaleBook">出售</a> <span class="shu">|</span>
					<a href="/index/inquire/showAllInquireBook">求购</a>
				</div>
			</div>
		</div>
		 <div class="personal_info">
			<div class="menu">
				<div class="menu_title">个人设置</div>
				<ul>
					<li class="menu_li">
						<a href="/index/personalcenter/edit" class="menu_a" id="baseLink">基本信息</a>
					</li>
					<li class="menu_li">
						<a href="/index/updatepwd/index" class="menu_a" id="passwordLink">修改密码</a>
					</li>
				</ul>
				
				<div class="menu_title">订单</div>
				<ul>
					<li class="menu_li"><a href="/index/orderreceive/alist" class="menu_a" id="orderreceiveLink">收到的订单</a></li>
					<li class="menu_li"><a href="/index/personalorder/alist" class="menu_a" id="personalorderLink">我下的订单</a></li>
				</ul>
				
				<div class="menu_title">书籍</div>
				<ul>
					<li class="menu_li"><a href="/index/personalsale/index" class="menu_a" id="personalsaleLink">出售书籍</a></li>
					<li class="menu_li"><a href="/index/personalinquiry/index" class="menu_a" id="personalinquiryLink">求购书籍</a></li>
				</ul>
				
				<div class="menu_title">留言</div>
				<ul>
					<li class="menu_li"><a href="/index/personalbcomment/index" class="menu_a" id="personalbcommentLink">出售留言</a></li>
					<li class="menu_li"><a href="/index/personalscomment/index" class="menu_a" id="personalscommentLink">求购留言</a></li>
				</ul>
			</div>
			<script type="text/javascript" src="../../../../static/js/front/jquery.min.js"></script>
			<script type="text/javascript">
             $(document).ready(function() {
	var path = window.document.location.pathname;
	var arr = path.split("/");
	switch(arr[2]){
		case 'personalcenter':
			$("#baseLink").addClass('on')
			break;
		case 'updatepwd':
			$("#passwordLink").addClass('on')
			break;
		case 'orderreceive':
			$("#orderreceiveLink").addClass('on')
			break;
		case 'personalorder':
			$("#personalorderLink").addClass('on')
			break;
		case 'personalsale':
			$("#personalsaleLink").addClass('on')
			break;
		case 'personalinquiry':
			$("#personalinquiryLink").addClass('on')
			break;
		case 'personalbcomment':
			$("#personalbcommentLink").addClass('on')
			break;
		case 'personalscomment':
			$("#personalscommentLink").addClass('on')
			break;
	}
});
</script>

			<!--基本信息-->
			<div class="menu_info" style="display: block;">
				<div class="menu_head" style="margin-bottom: 0px; border: none;">
					<ul>
						<li>求购留言</li>
					</ul>
				</div>
				<!--我的求购-->
				<div class="menu_detail" style="display: block;margin-top: 5px;">
					<div class="sc_right_content">
						<ul>
						<?php foreach($ret as $value): ?>
							<li>
								<div class="info_div" style="font-size: 14px;padding-left: 30px;line-height: 22px;">
									
										<div class="comment_time" style="color: #888;font-size: 12px;">
											<?php echo $value['scomment_time']; ?>
										</div>
										<div class="comment_content" style="color: #555;">
											<?php echo $value['scomment_content']; ?>
											<a href="/index/personalscomment/delete?id=<?php echo $value['scomment_id']; ?>" style="float: right;color: #666666;"><i class="fa fa-trash"></i></a>
										</div>
										<a href="/index/inquire/inquirydetail?id=<?php echo $value['inquiry_id']; ?>" target="_blank">
										<div class="comment_book" style="color: #00C7B4;">
											<?php echo $value['inquiry_name']; ?>
										</div>
									</a>
								</div>
							</li>
							<?php endforeach; ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
		
		 <!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="../../../../static/css/front/common_foot.css" />
	</head>
	<body>
		<div class="foot">
			<div class="foot_a">
				<span>买卖二手书,正版旧书,大学教材,旧书,就上校园二手书籍交易网:淘书街。
					<br>做最专业的校园二手书籍交易网站,求购或出售二手书,方便你我他。</span>
			</div>
		</div>
	</body>
</html>

	</body>
	<!--<script type="text/javascript" src="../../../../static/js/front/personal_center.js" ></script>-->
</html>
