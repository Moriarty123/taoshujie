<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:79:"E:\shixun\thinkphp5\public/../application/index\view\search\searchsale_yes.html";i:1546483519;s:51:"../Application/index/view/common/common_header.html";i:1546528502;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>淘书街-检索：<?php echo $keyword; ?></title>
		<link rel="shortcut icon" href="../../../../static/img/shu.ico" />
		<link rel="stylesheet" href="../../../../static/css/front/common_top.css" />
		<link rel="stylesheet" href="../../../../static/css/front/search_no.css" />
		<link rel="stylesheet" href="../../../../static/css/front/search_yes.css" />
		<link rel="stylesheet" href="../../../../static/css/front/page.css" />
		<link rel="stylesheet" href="../../../../static/css/front/common_foot.css" />
		<link rel="stylesheet" href="../../../../static/css/front/tongxun.css" />
		<style>
	a{
		color: #888;
	}
	#sort-nav1{
		margin-right: 30px;
		width: 1143px;
		height: 50px;
		float:left;	
		color:  #888;
		border: 1px solid #e3e3e3;
		cursor:pointer;
		margin-top: 10px;
		background: #f9f9f9;
	}
	#sort-nav1 ul,.sort-nav1 li{
		list-style: none;
		font-size: 14px;
	}
	#sort-nav1 li{
		float: left;
		text-align: center;
		border-color: #f9f9f9;
		padding: 0px 10px;
		height: 50px;
		width: 120px;
		line-height: 50px;
	}

	.item a,#sort-nav1 li a{
		padding: 0px 15px;
		text-decoration: none;
		font-size: 14px;
	}
	#sort-nav1 li a:hover{
		color: rgb(13, 179, 148);
	}
	.lihover,.selecthover{
		background-color:#FFF;
		
	}
	.prize-box {
		position: relative;
		display: inline-block;
	}
	.prize-content {
		display: none;
		position: absolute;
		left: -40px;
		top: 0px;
		width: 140px;
		height: 100px;
		background: #f9f9f9;
		box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
	}
	.prize-content li {
		display: block;
		font-size: 14px;
		left: 300px;
	}
	.prize-box:hover .prize-content {
		display: block;

	}
	.prize-content li:hover {
		color:#19a97b;
	}
	.content {
		width: 1145px;
		margin: 0px auto;

	}
	.related{
		border: 1px solid #e3e3e3;
		height: 18px;
		overflow: hidden;
		padding: 12px 19px;
		color: #9a9a9a;
		font-size: 14px;
	}
	.guess{
		color: #888;
		padding-left: 15px;
		float: left;
	}
	.link{
		overflow: hidden;
		color: #6c6c6c
	}
	.link span{
		padding: 0px 20px;
		text-align:center;
		cursor:pointer;
	}
	.resultaa{
		width: 1145px;
		margin: 0 auto;
		
		
	}
	.result-book{
		width: 210px;
		height: 350px;
		border: 1px solid #e3e3e3;
		float: left;
		margin: 20px 8px 0px 8px;
		text-align: center;
	}
	.cover img{
		width: 210px;
		height: 210px;

	}
	.decoration{
		padding:10px;
		font-size: 13px;
	}
	.prize{
		color:red;
		font-weight: bold;
		font-size: 16px;
		float: left;
		line-height: 30px;

	}
	.owner,.sold{
		color: #888;
		float: right;
		line-height: 30px;
	}
	.title{
		overflow: hidden;
		height: 56px;
		width: 200px;
		line-height: 18px;
		margin-top: 5px;
	}
	.quality{
		font-size: 15px;
		color: #888;
		line-height: 30px;
		float: left;
	}
	.owner a{
		text-decoration: underline;
	}
</style>
	</head>
	<body>
		
		<div class="q" id="q">
	<div class="top_content">
		<div class="welcome_txt">
			你好，欢迎来到淘书街！
		</div>
		<div class="right">
			请 <a href='/index/login/index' target="_blank">登录</a> 
			<a href='/index/register/index' style='color: #00CFBE; padding-left: 4px;' target="_blank">免费注册</a>
			<span class='shu'>|</span>
			<a href='/index/shopcar/index' target="_blank">购物车</a> <span class='shu'>|</span>
			<a href='/index/addsalebook/index' target="_blank">我要出售</a> <span class='shu'>|</span>
			<a href='/index/addinquirybook/index' target="_blank">我要求购</a> <span class='shu'>|</span>
			<a href='/admin/login/index' target="_blank">进入后台</a><span class='shu'>|</span><a style="display: inline-block;" onclick="show()">联系客服</a>
		</div>
	</div>
</div>
<div class="q" id="q1">
	<div class="top_content">
		<div class="welcome_txt">
			你好，欢迎来到淘书街！
		</div>
		<div class="right">
			<a href="/index/personalcenter/edit"><?php echo session('username');?></a> <span class='shu'>|</span>
			<a href='/index/shopcar/index'>购物车</a> <span class='shu'>|</span>
			<a href='/index/addsalebook/index' target="_blank">我要出售</a> <span class='shu'>|</span>
			<a href='/index/addinquirybook/index' target="_blank">我要求购</a> <span class='shu'>|</span>
			<a style="display: inline-block;cursor: pointer;" onclick="show()">联系客服</a><span class='shu'>|</span>
			<a href='/admin/login/index' target="_blank">进入后台</a>
			
		</div>
	</div>
</div>
<?php $a = session('username');if((!isset($a) || session('username')=='')): ?> 
<script type='text/javascript'>
	document.getElementById('q').style.display = 'block';
	document.getElementById('q1').style.display = 'none';
</script>

<?php else: ?>
<script type='text/javascript'>
	document.getElementById('q1').style.display = 'block';
	document.getElementById('q').style.display = 'none';
</script>
<?php endif; ?>
<div class="w">
	<!--头部-->
	<div class="top">
		<div class="logo">
			<a href="?"><img src="/static/img/taoshujie.png" /></a>
		</div>
		<form action="/index/search/searchsale" method="post" class="search" onsubmit="checkSearch();">
			<div class="search_div">
				<input type="text" placeholder="出售书籍名称" name="keyword" class="search_a"/>
				<input type="submit" class="search_b" value="搜索"></input>
			</div>
		</form>
	</div>
</div>
<!--导航栏-->
<div class="nav">
	<div class="nav_bar">
		<div class="all_type nav_active">
			全部图书分类
			<span class="all_type_a"></span>
		</div>
		<div class="nav_r">
			<ul id="nav_qa">
				<a href="/index/index/index"><li>首页</li></a>
				<a href="/index/type/showAllTypeSecond"><li>分类</li></a>
				<a href="/index/sale/showAllSaleBook"><li>出售</li></a>
				<a href="/index/inquire/showAllInquireBook"><li>求购</li></a>
			</ul>
		</div>
	</div>
</div>
<script type="text/javascript" src="../../../../static/js/front/jquery.min.js"></script>
<script type="text/javascript">
      //菜单栏的点击颜色切换
   	    var pn = location.pathname;
        var as = document.getElementById('nav_qa').getElementsByTagName("a");   
        for (var i = 0, j = as.length; i < j; i++){
           
            if(pn.length>3){
       
                if (as[i].href.indexOf(pn) != -1) {as[i].className = 'nav_active'; break; }
            }
        }
        if(pn.length<3){as[0].className = 'nav_active';}

        function show(){
        	$('#jstx').fadeIn();
        }
        function showno(){
        	$('#jstx').fadeIn();
        }

</script>

<!-- 实时通讯 -->
<div style="width: 500px;height: 490px;border: 2px solid #00C7B4;position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%); border-radius: 5px;padding:2px 0px;background: #FFF;z-index: 1200;display:none;" id="jstx">
		<div class="title-content">
			<div class="tao-img"><img src="../../../../static/img/taoshujie.png"></div>
			<div class="chat-close"><i class="fas fa-chevron-circle-down close" onclick="showno()"></i></div>
			<div class="chat-title">
				<div class="chat-text">
					<div class="chat-people">人工客服--小美</div>
					<div class="chat-mags">正在为您服务，请稍等</div>
				</div>
				<div class="chat-img"><img src="../../../../static/img/1.jpg"></div>
			</div>
		</div>
		<!-- 内容信息 -->
		<div style="width: 100%;height: 60%;overflow: hidden;overflow-y:scroll;background:#F5F5F5;" id="yujia">
			
		</div>
		<!-- 内容信息结束 -->
		<div class="send-content" >
			<!-- 表情 -->
			<div class="send-icon"><i class="far fa-grin-squint smile"  onclick="slideDownEmojiBox()"></i>
				<div id="emoji-box" >
					
					<div  class="cha" style="height: 28px">
						<span onclick="slideUpEmojiBox()">X</span>
					</div>
					<div style="height: 180px;overflow: hidden;overflow-y: scroll;">
						<?php $__FOR_START_18043__=1;$__FOR_END_18043__=132;for($i=$__FOR_START_18043__;$i < $__FOR_END_18043__;$i+=1){ ?>
						<img src="/static/img/qq/<?php echo $i; ?>.gif" style="margin: 5px" onclick="selectEmoji(this)">
						<?php } ?>
					</div>
				</div>
			
			</div>
			<!-- 表情结束 -->
			<div class="send-box" contenteditable="true" id="aaa"></div>
			<div class="send-button" onclick="chat()"><i class="fas fa-location-arrow sbutton"></i></div>
			
		</div>

	</div>

<script type="text/javascript" src="http://cdn.goeasy.io/goeasy.js"></script>
<script type="text/javascript" charset="UTF-8">
		var a = document.getElementById('aaa');
		var goEasy = new GoEasy({
		appkey: 'BC-beea5de574d04e92ba6e75553432fcfe'
		});
        
        function showno(){
        	$('#jstx').fadeOut();
        }

		
		goEasy.subscribe({
		channel:'yujia',
		onMessage: function(message){
			
			  	$('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;height:40px;background:#FFF;border-radius: 5px;margin-top:5px;margin-left:10px;padding:5px 10px;font-size:15px;line-height:30px;'>"+message.content+'</span></div>');
			
		}


		});
		//发送信息
		function chat(){

			goEasy.publish({
			channel:'yujialiang',
			message: a.innerHTML
			});
			var w = a.innerHTML;
			$('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;float:right;height:40px;background:#0cecd8;border-radius: 5px;margin-top:5px;margin-right:10px;padding:5px 10px;font-size:15px;line-height:30px;'>"+w+'</span></div>');

			$('#aaa').html("");
		}

		//选择表情
			function slideDownEmojiBox(){
				$('#emoji-box').slideDown();
			}
			function slideUpEmojiBox(){
				$('#emoji-box').slideUp();
			}
			function selectEmoji(obj){
				var img_src=$(obj).attr('src');
				var html="<img src='"+img_src+"'/>";
				$('#aaa').append(html);
				slideUpEmojiBox();
			}

		//滚动条
		function sc() 
		{ 
	    var e=document.getElementById("yujia");
	    if(e)
	        e.scrollTop=e.scrollHeight;          
		}
		$(document).ready(function(){
		//等加载完再运行
		    setInterval("sc()",10);

		});
</script>
<!-- 实时通讯 -->
		
		<div class="content">
		<div class="related">
			<div class="guess">亲是不是想找：</div>
			<div class="link">
				<?php foreach($wantsearch as $want): ?>
				<span onclick="search('<?php echo $want; ?>')"><?php echo $want; ?></span>
				<?php endforeach; ?>
			</div>
		</div>
		<div id="sort-nav1" >
			<ul>
				<li>
					<a href="/index/search/orderbycomprehensive?keyword=<?php echo $keyword; ?>">综合排序</a>
				</li>
				<li>
				<a href="/index/search/orderbyprice?keyword=<?php echo $keyword; ?>&type=desc&control=sale_new">新旧程度</a>
				</li>
				<li>
					<a href="/index/search/orderbysalesum?keyword=<?php echo $keyword; ?>">销量</a>
				</li>
				<li>
					<a href="/index/search/orderbyprice?keyword=<?php echo $keyword; ?>&type=desc&control=sale_num">库存</a>
				</li>
				<li><span class="prize-box">价格<img src="../../../../static/img/coin20.png">
					<div class="prize-content" > 
						<ul>
							
								<li style="font-weight: normal" onclick=""><a href="/index/search/orderbyprice?keyword=<?php echo $keyword; ?>&type=desc&control=sale_afprice">价格从高到低</a></li>
							
							
								<li style="font-weight: normal" onclick=""><a href="/index/search/orderbyprice?keyword=<?php echo $keyword; ?>&type=asc&control=sale_afprice">价格从低到高</a></li>
							
						</ul>
				<li>
					<a href="/index/search/pacon?keyword=<?php echo $keyword; ?>">孔夫子网</a>
				</li>
					</div>
					</span>
				</li>
			</ul>
		</div>
		
		<div class="resultaa">
			<?php foreach($res as $vo): ?>
			<div class="result-book">
				<div class="cover">
					<a href="/index/sale/saledetail?id=<?php echo $vo['sale_id']; ?>"><img src="<?php echo $vo['sale_img']; ?>"></a>
					<div class="decoration">
						<div style="height: 20px">
							<div class="prize"><?php echo $vo['sale_afprice']; ?></div>
							<div class="sold">

								<?php foreach($rew as $re): if(($vo['sale_id']==$re['book_id'])): ?>
										 <?php echo $re['a']; endif; endforeach; if(!in_array($vo['sale_id'],$data)): ?>
								<?php echo '0'; endif; ?>
							人付款
							</div>
						</div>
						<div class="title"><?php echo $vo['sale_content']; ?></div>
						<div class="quality">
							<?php echo $vo['sale_degrees']; ?>
						</div>
						<div class="owner">来自<a href="/index/personalsalecenter/index?id=<?php echo $vo['user_id']; ?>"><?php echo $vo['user_realname']; ?></a></div>
					</div>
				</div>
			</div>
			<?php endforeach; ?>
		</div>

	</div>
	<!-- footer开始 -->
		<div class="foot" style="clear: both;position: relative;top: 80px;">
			<div class="foot_a">
				<span>买卖二手书,正版旧书,大学教材,旧书,就上校园二手书籍交易网:淘书街。
					<br>做最专业的校园二手书籍交易网站,求购或出售二手书,方便你我他。</span>
			</div>
		</div>
		<!-- footer结束 -->
	<script src="../../../../static/js/front/jquery.min.js"></script>
	<script type="text/javascript">
		$("#sort-nav1 ul li").click(function(){
			$(this).addClass("selecthover").siblings().removeClass("selecthover");
		}).hover(function(){
			$(this).addClass("lihover");
		},function () {
			$(this).removeClass("lihover");
		});
      //点击发送关键词查找
		function search(obj) {
			$.post('/index/search/searchsale',{'keyword':obj},function(ret){
			
			},'html');
		}
	</script>
	</body>
	<script type="text/javascript" src="../../../../static/js/front/common_top.js" ></script>
</html>
