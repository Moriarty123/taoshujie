<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:82:"F:\study\www\taoshujie\thinkphp5\public/../application/index\view\index\index.html";i:1546527254;s:51:"../Application/index/view/common/common_header.html";i:1546528502;s:49:"../Application/index/view/common/common_foot.html";i:1544954783;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>欢迎来到淘书街</title>
		<link rel="shortcut icon" href="../../../../static/img/shu.ico" />
		<link rel="stylesheet" href="../../../../static/fontawesome-5.5.0/css/all.css" />	
		<link rel="stylesheet" href="../../../../static/css/front/index.css"/>
		<link rel="stylesheet" href="../../../../static/css/front/common_top.css" />
		<link rel="stylesheet" href="../../../../static/css/front/top.css" />
		<link rel="stylesheet" href="../../../../static/css/front/tongxun.css" />
		
		<link rel="stylesheet" href="../../../../static/font/css/font-awesome.min.css" />
		<link rel="stylesheet" href="http://jrain.oscitas.netdna-cdn.com/tutorial/css/fontawesome-all.min.css" />
		<script type="text/javascript">
        window.onload = function main() {
        	console.log("余嘉亮贼帅");
            Tabs(".list-item", ".contents", "list-item-checked", "contents-checked");

        }
    	</script>
    <style type="text/css">
	*,
*:after,
*:before {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}
.row{
	float: left;
	padding:22px;
}
	.product-grid{
		position: relative;
		width: 180px;
		height: 280px;
		padding:10px;
	}
	.product-image{
		width: 160px;
		height: 210px;
		position: relative;
	}
	.product-image img{
		width: 100%;
		height:100%;
	}
	.product-image:before{
		content: "";
		background: rgba(0,0,0,0.3);
		width: 100%;
		height:100%;
		opacity: 0;
		position: absolute;
		top: 0;
		left: 0;
		z-index: 1;
	}
	.product-grid:hover .product-image:before{ 
		opacity: 1; 
	}
	.product-grid .product-image a{ display: block; }
	.product-image .pic-1{
		opacity: 1;
		/*backface-visibility: hidden;*/
	}
	.product-grid:hover .product-image .pic-1{ opacity: 0; }
	.product-image .pic-2{
		width: 100%;
		height: 100%;
		opacity: 0;
		backface-visibility: hidden;
		transform: scale(1.3);
		position: absolute;
		top: 0;
		left: 0;
		transition: all 0.4s ease-out 0s;
	}
	.product-grid:hover .product-image .pic-2 {
		opacity: 1;
		transform: scale(1);
	}
	.product-grid .social {
		padding: 0;
		margin: 0;
		list-style: none;
		transform: translateY(-50%);
		position: absolute;
		top: 50%;
		left: 10px;
		z-index: 4;
	}
	.product-grid .social li {
		margin: 0 0 12px;
		opacity: 0;
		transform: translateX(-60px);
		transition: transform .3s ease-out 0s;
	}
	.product-grid:hover .social li {
		opacity: 1;
		transform: translateX(0);
	}
	.product-grid .social li a {
		color: #fff;
		font-size: 18px;
	}
	.product-grid .social li a:hover { color: #e74c3c;; }
	.product-grid .social li a:before,
	.product-grid .social li a:after{
		content: attr(data-tip);
		color: #000;
		background: #fff;
		font-size: 14px;
		padding: 5px 10px;
		white-space: nowrap;
		display: none;
		transform: translateY(-50%);
		position: absolute;
		left: 33px;
		top: 50%;
	}
	.product-grid .social li a:after{
		content: '';
		background: linear-gradient(-45deg, #fff 49%, transparent 50%);
		width: 10px;
		height: 10px;
		top: 40%;
		left: 20px;
	}
	.product-grid .social li a:hover:before,
	.product-grid .social li a:hover:after{
		  display: block;
	}
	.product-grid .product-content{ padding: 12px 0; }
	.product-grid .price{
		color: #333;
		font-size: 14px;
		font-weight: 400;
		padding:10px;
	}
	.product-grid .price span{
		color: #333;
		text-decoration: line-through;
		margin-right: 3px;
	}
	.product-grid .price.discount{ color: #e74c3c;padding: 10px; }

	</style>

	</head>
	<body>

		<div class="q" id="q">
	<div class="top_content">
		<div class="welcome_txt">
			你好，欢迎来到淘书街！
		</div>
		<div class="right">
			请 <a href='/index/login/index' target="_blank">登录</a> 
			<a href='/index/register/index' style='color: #00CFBE; padding-left: 4px;' target="_blank">免费注册</a>
			<span class='shu'>|</span>
			<a href='/index/shopcar/index' target="_blank">购物车</a> <span class='shu'>|</span>
			<a href='/index/addsalebook/index' target="_blank">我要出售</a> <span class='shu'>|</span>
			<a href='/index/addinquirybook/index' target="_blank">我要求购</a> <span class='shu'>|</span>
			<a href='/admin/login/index' target="_blank">进入后台</a><span class='shu'>|</span><a style="display: inline-block;" onclick="show()">联系客服</a>
		</div>
	</div>
</div>
<div class="q" id="q1">
	<div class="top_content">
		<div class="welcome_txt">
			你好，欢迎来到淘书街！
		</div>
		<div class="right">
			<a href="/index/personalcenter/edit"><?php echo session('username');?></a> <span class='shu'>|</span>
			<a href='/index/shopcar/index'>购物车</a> <span class='shu'>|</span>
			<a href='/index/addsalebook/index' target="_blank">我要出售</a> <span class='shu'>|</span>
			<a href='/index/addinquirybook/index' target="_blank">我要求购</a> <span class='shu'>|</span>
			<a style="display: inline-block;cursor: pointer;" onclick="show()">联系客服</a><span class='shu'>|</span>
			<a href='/admin/login/index' target="_blank">进入后台</a>
			
		</div>
	</div>
</div>
<?php $a = session('username');if((!isset($a) || session('username')=='')): ?> 
<script type='text/javascript'>
	document.getElementById('q').style.display = 'block';
	document.getElementById('q1').style.display = 'none';
</script>

<?php else: ?>
<script type='text/javascript'>
	document.getElementById('q1').style.display = 'block';
	document.getElementById('q').style.display = 'none';
</script>
<?php endif; ?>
<div class="w">
	<!--头部-->
	<div class="top">
		<div class="logo">
			<a href="?"><img src="/static/img/taoshujie.png" /></a>
		</div>
		<form action="/index/search/searchsale" method="post" class="search" onsubmit="checkSearch();">
			<div class="search_div">
				<input type="text" placeholder="出售书籍名称" name="keyword" class="search_a"/>
				<input type="submit" class="search_b" value="搜索"></input>
			</div>
		</form>
	</div>
</div>
<!--导航栏-->
<div class="nav">
	<div class="nav_bar">
		<div class="all_type nav_active">
			全部图书分类
			<span class="all_type_a"></span>
		</div>
		<div class="nav_r">
			<ul id="nav_qa">
				<a href="/index/index/index"><li>首页</li></a>
				<a href="/index/type/showAllTypeSecond"><li>分类</li></a>
				<a href="/index/sale/showAllSaleBook"><li>出售</li></a>
				<a href="/index/inquire/showAllInquireBook"><li>求购</li></a>
			</ul>
		</div>
	</div>
</div>
<script type="text/javascript" src="../../../../static/js/front/jquery.min.js"></script>
<script type="text/javascript">
      //菜单栏的点击颜色切换
   	    var pn = location.pathname;
        var as = document.getElementById('nav_qa').getElementsByTagName("a");   
        for (var i = 0, j = as.length; i < j; i++){
           
            if(pn.length>3){
       
                if (as[i].href.indexOf(pn) != -1) {as[i].className = 'nav_active'; break; }
            }
        }
        if(pn.length<3){as[0].className = 'nav_active';}

        function show(){
        	$('#jstx').fadeIn();
        }
        function showno(){
        	$('#jstx').fadeIn();
        }

</script>

<!-- 实时通讯 -->
<div style="width: 500px;height: 490px;border: 2px solid #00C7B4;position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%); border-radius: 5px;padding:2px 0px;background: #FFF;z-index: 1200;display:none;" id="jstx">
		<div class="title-content">
			<div class="tao-img"><img src="../../../../static/img/taoshujie.png"></div>
			<div class="chat-close"><i class="fas fa-chevron-circle-down close" onclick="showno()"></i></div>
			<div class="chat-title">
				<div class="chat-text">
					<div class="chat-people">人工客服--小美</div>
					<div class="chat-mags">正在为您服务，请稍等</div>
				</div>
				<div class="chat-img"><img src="../../../../static/img/1.jpg"></div>
			</div>
		</div>
		<!-- 内容信息 -->
		<div style="width: 100%;height: 60%;overflow: hidden;overflow-y:scroll;background:#F5F5F5;" id="yujia">
			
		</div>
		<!-- 内容信息结束 -->
		<div class="send-content" >
			<!-- 表情 -->
			<div class="send-icon"><i class="far fa-grin-squint smile"  onclick="slideDownEmojiBox()"></i>
				<div id="emoji-box" >
					
					<div  class="cha" style="height: 28px">
						<span onclick="slideUpEmojiBox()">X</span>
					</div>
					<div style="height: 180px;overflow: hidden;overflow-y: scroll;">
						<?php $__FOR_START_5394__=1;$__FOR_END_5394__=132;for($i=$__FOR_START_5394__;$i < $__FOR_END_5394__;$i+=1){ ?>
						<img src="/static/img/qq/<?php echo $i; ?>.gif" style="margin: 5px" onclick="selectEmoji(this)">
						<?php } ?>
					</div>
				</div>
			
			</div>
			<!-- 表情结束 -->
			<div class="send-box" contenteditable="true" id="aaa"></div>
			<div class="send-button" onclick="chat()"><i class="fas fa-location-arrow sbutton"></i></div>
			
		</div>

	</div>

<script type="text/javascript" src="http://cdn.goeasy.io/goeasy.js"></script>
<script type="text/javascript" charset="UTF-8">
		var a = document.getElementById('aaa');
		var goEasy = new GoEasy({
		appkey: 'BC-beea5de574d04e92ba6e75553432fcfe'
		});
        
        function showno(){
        	$('#jstx').fadeOut();
        }

		
		goEasy.subscribe({
		channel:'yujia',
		onMessage: function(message){
			
			  	$('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;height:40px;background:#FFF;border-radius: 5px;margin-top:5px;margin-left:10px;padding:5px 10px;font-size:15px;line-height:30px;'>"+message.content+'</span></div>');
			
		}


		});
		//发送信息
		function chat(){

			goEasy.publish({
			channel:'yujialiang',
			message: a.innerHTML
			});
			var w = a.innerHTML;
			$('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;float:right;height:40px;background:#0cecd8;border-radius: 5px;margin-top:5px;margin-right:10px;padding:5px 10px;font-size:15px;line-height:30px;'>"+w+'</span></div>');

			$('#aaa').html("");
		}

		//选择表情
			function slideDownEmojiBox(){
				$('#emoji-box').slideDown();
			}
			function slideUpEmojiBox(){
				$('#emoji-box').slideUp();
			}
			function selectEmoji(obj){
				var img_src=$(obj).attr('src');
				var html="<img src='"+img_src+"'/>";
				$('#aaa').append(html);
				slideUpEmojiBox();
			}

		//滚动条
		function sc() 
		{ 
	    var e=document.getElementById("yujia");
	    if(e)
	        e.scrollTop=e.scrollHeight;          
		}
		$(document).ready(function(){
		//等加载完再运行
		    setInterval("sc()",10);

		});
</script>
<!-- 实时通讯 -->

		<!--中间部分-->
		<div class="content">
			<!--左边框-->
			<div class="content_a">
				<!--详细分类-->
				<div class="content_a_up">
					<ul>
						<li class="type_li">
							<div class="max_type_title">
								<span>经济金融</span><i class=" fa fa-angle-right"></i>
							</div>
							<div class="min_type">
								<?php foreach($type_second_jj as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank"><?php echo $value['second_name']; ?></a>
								<?php } ?>
							</div>
						</li>
						<li class="type_li">
							<div class="max_type_title">
								<span>计算机与网络</span><i class=" fa fa-angle-right"></i>
							</div>
							<div class="min_type">
								<?php foreach($type_second_jsj as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank"><?php echo $value['second_name']; ?></a>
								<?php } ?>
							</div>
						</li>
						<li class="type_li">
							<div class="max_type_title">
								<span>管理</span><i class=" fa fa-angle-right"></i>
							</div>
							<div class="min_type">
								<?php foreach($type_second_gl as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank"><?php echo $value['second_name']; ?></a>
								<?php } ?>
							</div>
						</li>
						<li class="type_li">
							<div class="max_type_title">
								<span>语言学习</span><i class=" fa fa-angle-right"></i>
							</div>
							<div class="min_type">
								<?php foreach($type_second_yy as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank"><?php echo $value['second_name']; ?></a>
								<?php } ?>
							</div>
						</li>
						<li class="type_li">
							<div class="max_type_title">
								<span>文学小说</span><i class=" fa fa-angle-right"></i>
							</div>
							<div class="min_type">
								<?php foreach($type_second_wx as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank"><?php echo $value['second_name']; ?></a>
								<?php } ?>
							</div>
						</li>
						<li class="type_li">
							<div class="max_type_title">
								<span>医学卫生</span><i class=" fa fa-angle-right"></i>
							</div>
							<div class="min_type">
								<?php foreach($type_second_yx as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank"><?php echo $value['second_name']; ?></a>
								<?php } ?>
							</div>
						</li>
						<li class="type_li">
							<div class="max_type_title">
								<span>教育考试</span><i class=" fa fa-angle-right"></i>
							</div>
							<div class="min_type">
								<?php foreach($type_second_jy as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank"><?php echo $value['second_name']; ?></a>
								<?php } ?>
							</div>
						</li>
						<div class="type_div" style="top: 0px;">
							<div class="title">经济金融</div>
							<div class="detail_div">
								<?php foreach($type_second_ajj as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank" class="detail">
									<?php echo $value['second_name']; ?>
								</a>
								<?php } ?>
							</div>
						</div>
						<div class="type_div" style="top: 104px;">
							<div class="title">计算机与网络</div>
							<div class="detail_div">
								<?php foreach($type_second_ajsj as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank" class="detail">
									<?php echo $value['second_name']; ?>
								</a>
								<?php } ?>
							</div>
						</div>
						<div class="type_div" style="top: 208px;">
							<div class="title">管理</div>
							<div class="detail_div">
								<?php foreach($type_second_agl as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank" class="detail">
									<?php echo $value['second_name']; ?>
								</a>
								<?php } ?>
							</div>
						</div>
						<div class="type_div" style="top: 312px;">
							<div class="title">语言学习</div>
							<div class="detail_div">
								<?php foreach($type_second_ayy as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank" class="detail">
									<?php echo $value['second_name']; ?>
								</a>
								<?php } ?>
							</div>
						</div>
						<div class="type_div" style="top: 416px;">
							<div class="title">文学小说</div>
							<div class="detail_div">
								<?php foreach($type_second_awx as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank" class="detail">
									<?php echo $value['second_name']; ?>
								</a>
								<?php } ?>
							</div>
						</div>
						<div class="type_div" style="top: 520px;">
							<div class="title">医学卫生</div>
							<div class="detail_div">
								<?php foreach($type_second_ayx as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank" class="detail">
									<?php echo $value['second_name']; ?>
								</a>
								<?php } ?>
							</div>
						</div>
						<div class="type_div" style="top: 624px;">
							<div class="title">教育考试</div>
							<div class="detail_div">
								<?php foreach($type_second_ajy as $key => $value){ ?>
								<a href="/index/sale/classdetail?second_name=<?php echo $value['second_name']; ?>" target="_blank" class="detail">
									<?php echo $value['second_name']; ?>
								</a>
								<?php } ?>
							</div>
						</div>
					</ul>
					<div class="type_more">
						<a href="/index/type/showAllTypeSecond">浏览所有图书分类</a><i class=" fa fa-angle-right"></i>
					</div>
					
				</div>
				<!--详细分类结束-->
				<!--最新书籍开始-->
		<div class="content_a_down">
			<div class="content_a_down_title">最新书籍</div>
			  <div class="container">
			  	<?php foreach($sale_book as $vat): ?>
			  	<div class="box box1">
			  		<div class="name">
			  			<a><?php echo $vat['sale_name']; ?></a>
			  		</div>
			  		<div class="book_dec">
			  			<a href="/index/sale/saledetail?id=<?php echo $vat['sale_id']; ?>">
			  			<div class="book_dec_img"><img src="<?php echo $vat['sale_img'] ?>"></div>
			  			<div class="book_dec_title"><?php echo $vat['sale_name']; ?></div>
			  			<div class="book_dec_pub"><?php echo $vat['sale_publishing']; ?></div>
			  			<div class="book_dec_prize">￥<?php echo $vat['sale_afprice']; ?></div>
			  			</a>
			  		</div>

			  	</div>
			  	<?php endforeach; ?>				
			  </div>
		</div>
				<!--最新书籍结束-->
				<div class="content_a_down">
					<div class="content_a_down_title">销量排行榜</div>
					<ul id="list-title">
					    <li class="list-item list-item-checked">周</li>
					    <li class="list-item">月</li>
					    <li class="list-item">年</li>
					</ul>
			    <div id="content-box">
                   <div class="contents contents-checked" >

					<ul class="newbook_ul">
					<?php foreach($ret_w as $vo): ?>
						<li class="newbook_li">
							<a href="/index/sale/saledetail?id=<?php echo $vo['book_id']; ?>" target="_blank">
					<?php echo $vo['book_name']; ?>
							</a>
						</li>
					<?php endforeach; ?>
					</ul>
                   </div>
                   <div class="contents" >

					<ul class="newbook_ul">
					<?php foreach($ret_m as $vo): ?>
						<li class="newbook_li">
							<a href="/index/sale/saledetail?id=<?php echo $vo['book_id']; ?>" target="_blank">
							<?php echo $vo['book_name']; ?>
							</a>
						</li>
					<?php endforeach; ?>
					</ul>
                   </div>
                   <div class="contents">
                   	
					<ul class="newbook_ul">
					<?php foreach($ret_y as $vo): ?>
						<li class="newbook_li">
							<a href="/index/sale/saledetail?id=<?php echo $vo['book_id']; ?>" target="_blank">
							<?php echo $vo['book_name']; ?>
							</a>
						</li>
					<?php endforeach; ?>
					</ul>
                   </div>
                </div> 
				</div>
			</div>
			<!--左边框结束-->
			
			<!--轮播图-->
			<div class="content_b" id="lunbo_img">
				<div class="content_img">
				<div class="img_box">
			<img src="../../../../static/img/img1.jpg">
			<img src="../../../../static/img/img2.jpg">
			<img src="../../../../static/img/img3.jpg">
		    </div> 
			<ul class="ul5">
				<li></li>
				<li></li>
				<li></li>
			</ul>
			<div class="d1"><</div>
			<div class="d2">></div>
		    </div>
			</div>
			
			<!--登录/公告-->
			<div class="content_c">
				<!--登录框-->
				
				<div id="a">
					<div class="personal">
						<div class="p_img"><img src="/static/img/default.jpg" /></div>
						<div class="welcome">Hello~<br>欢迎来到淘书街</div>
						<div class="p_c">
							<a href='/index/login/index'>登录</a>
							<a href='/index/register/index'>注册</a>
						</div>
					</div>
				</div>
				<div id="a1">
					<div class="personal">
						<div class="p_img"><img src="<?php echo session('user_img');?>" /></div>
						<div class="welcome">~<?php echo session('username');?><br>欢迎来到淘书街</div>
						<div class="p_c">
							<a href="/index/personalcenter/edit">个人中心</a>
							<a href="/index/login/logout">退出登录</a>
						</div>
					</div>
				</div>
				<?php
				$a = session('username');
				if(!isset($a) || session('username')==''){  
					echo "<script type='text/javascript'>
							document.getElementById('a').style.display = 'block';
							document.getElementById('a1').style.display = 'none';
						</script>";
		        }
		        else{
		      	    echo "<script type='text/javascript'>
		      	    		document.getElementById('a1').style.display = 'block';
		      	    		document.getElementById('a').style.display = 'none';
		      	    	</script>";
		        }
				?>
				<div class="gonggao">
					<div class="gonggao_title">公告</div>
					<div class="gonggao_detail">
						<ul>
							<?php foreach ($notice as $key => $rec) { ?>
							<li><a href="/index/notice/index?id=<?php echo $rec['notice_id']; ?>" target="_blank"><?php echo $rec['notice_title']; ?></a></li>
							<?php } ?>
						</ul>
					</div>
				</div>
			</div>
			<!--登录/公告结束-->
			
			<!--出售书籍-->
			<div class="content_d">
				<div class="c_d_title">
					<span>出售书籍</span>
				</div>
				<?php foreach($sale_book as $rec): ?>
				<div class="row">
				<div class="product-grid">
					<div class="product-image">
						<a href="#">
							<img class="pic-1" src="<?php echo $rec['sale_img']; ?>">
							<img class="pic-2" src="<?php echo $rec['sale_img']; ?>">
						</a>
						
						<ul class="social">
							<li><a href="/index/shopcar/insert?id=<?php echo $rec['sale_id']; ?>" data-tip="加入购物车"><i class="fas fa-shopping-cart"></i></a></li>
							<li><a href="/index/sale/saledetail?id=<?php echo $rec['sale_id']; ?>" data-tip="查看详情"><i class="fas fa-search"></i></a></li>
						</ul>
					</div>
					<div class="product-content">
					<div class="price discount"><span><?php echo $rec['sale_beprice']; ?></span><?php echo $rec['sale_afprice']; ?></div>
				</div>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
			<!--出售书籍结束-->
			
			<!--求购书籍-->
		<div class="content_d">
				<div class="c_d_title">
					<span>求购书籍</span>
				</div>
				<?php foreach($inquiry_book as $rec): ?>
				<div class="row">
				<div class="product-grid">
					<div class="product-image">
						<a href="#">
							<img class="pic-1" src="<?php echo $rec['inquiry_img']; ?>">
							<img class="pic-2" src="<?php echo $rec['inquiry_img']; ?>">
						</a>
						
						<ul class="social">
	
							<li><a href="/index/inquire/inquirydetail?id=<?php echo $rec['inquiry_id']; ?>" data-tip="查看详情"><i class="fas fa-search"></i></a></li>
						</ul>
					</div>
					<div class="product-content">
					<div class="price discount"><span><?php echo $rec['inquiry_minprice']; ?></span><?php echo $rec['inquiry_maxprice']; ?></div>
				</div>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
			<!--求购书籍结束-->
	</div>

		<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="../../../../static/css/front/common_foot.css" />
	</head>
	<body>
		<div class="foot">
			<div class="foot_a">
				<span>买卖二手书,正版旧书,大学教材,旧书,就上校园二手书籍交易网:淘书街。
					<br>做最专业的校园二手书籍交易网站,求购或出售二手书,方便你我他。</span>
			</div>
		</div>
	</body>
</html>

	</body>
	
	<script type="text/javascript" src="../../../../static/js/front/index.js" ></script>
	<script type="text/javascript" src="../../../../static/js/front/common_top.js" ></script>
	<script type="text/javascript" src="../../../../static/js/front/jquery.min.js" ></script>
	<script type="text/javascript" src="../../../../static/js/front/tab.js" ></script>
	<script type="text/javascript" src="../../../../static/js/front/ban.js" ></script>
	
</html>
