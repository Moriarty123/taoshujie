<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:71:"E:\shixun\thinkphp5\public/../application/admin\view\user\userEdit.html";i:1546156729;s:44:"../application/admin/view/common/header.html";i:1546404727;s:42:"../application/admin/view/common/menu.html";i:1546156729;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>淘书街修改会员信息</title>
		<link rel="shortcut icon" href="/static/img/shu.ico" />
		<link rel="stylesheet" href="/static/css/back/user.css" />
		<link rel="stylesheet" href="/static/css/back/common.css" />
		<link rel="stylesheet" href="/static/css/back/add.css" />
		<link rel="stylesheet" href="/static/css/back/edit.css" />
		
		<script type="text/javascript" src="/static/js/back/jquery.min.js"></script>
		<script type="text/javascript" src="/static/js/back/public.js"></script>
		<script type="text/javascript" src="/static/js/back/addUser.js"></script>
		<!-- <script type="text/javascript" src="/static/js/back/showImg.js"></script> -->


		<style>
			.tip {
				display: none; padding-left: 83px; padding-top: 5px; color: red;
			}
		</style>
	</head>
	<body>
	<!-- 头部	 -->
	<!-- 头部 -->
<div class="head">
	<div class="headL">
		<img class="headLogo" src="/static/img/admin_logo.png"/>
	</div>
	<div class="headR">
		<span style="margin-bottom: 8px;display: inline-block;">
			<!-- 日历 -->
			<SCRIPT type=text/javascript src="../../../js/back/clock.js"></SCRIPT>
			<SCRIPT type=text/javascript>showcal();</SCRIPT>
        </span>
        <br />
        <div class="head_op">
	    	<?php if(\think\Session::get('admin_id') == ''): ?>
	    	<a href="/admin/login/index" >【登录】</a>
	    	<?php else: ?>
	    	<span>欢迎你，</span>
	    	<a href="" >【<?php echo \think\Session::get('admin_name'); ?>】</a>
	    	<a href="/admin/login/logout" >【安全退出】</a>
	    	<?php endif; ?>
			<a href="/index/index/index">【回到前台】</a>
			<a style="display:inline-block;cursor: pointer;" onclick="show()">【客户服务】</a>
        </div>
	</div>
</div>
<!-- 实时通讯 -->
<div style="display:none;z-index:1200;width: 500px;height: 490px;border: 1px solid red;position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%);border: 10px solid #00C7B4;border-radius: 5px;background: #FFF;" id="jstx">
			<div style="width: 100%;height: 15%;border-bottom:3px solid #00C7B4;background: #F5F5F5;">

			</div>
			<!-- 内容信息 -->
			<div style="width: 100%;height: 65%;overflow: hidden;"id="yujia">
			
			</div>
			<!-- 内容信息结束 -->
			<div style="width: 100%;height: 20%;">
				<div style="width: 100%;height:55%;border-top: 3px solid #00C7B4;overflow: hidden;"contenteditable="true" id="aaa"></div>

				<div style="width: 100%,height:10%;background:#00C7B4;">
					<a style="display: block;width: 50px;height: 20px;cursor: pointer;background:#08AFA0;color:#FFF;text-align: center;line-height: 20px;position: relative;top: 15px;left: 190px;cursor: pointer;" onclick="showno()">取消</a>
					<a style="display: block;width: 50px;height: 20px;cursor: pointer;background:#08AFA0;color:#FFF;text-align: center;line-height: 20px;position: relative;top: -5px;left: 250px;" onclick="chat()">发送</a>
				</div>
			</div>

	</div>
<script type="text/javascript" src="../../../../static/js/front/jquery.min.js"></script>
<script type="text/javascript" src="http://cdn.goeasy.io/goeasy.js"></script>
<script type="text/javascript">
			function show(){
				$('#jstx').fadeIn();
			}
			function showno(){
				$('#jstx').fadeOut();
			}
			var b = document.getElementById('aaa');
			var goEasy = new GoEasy({
			appkey: 'BC-beea5de574d04e92ba6e75553432fcfe'
			});

			var a = document.getElementById('yujia');
			goEasy.subscribe({
			channel:'yujialiang',
			onMessage: function(message){
				
			   $('#yujia').append("<br><span style='display: inline-block;height: 30px;line-height:30px;background:#FFF;border:1px solid gray;border-radius: 5px;float: left;margin-top:5px;margin-left:10px;padding:3px;'>"+message.content+'</span><br>');


				console.log('收到：'+message.content);
			}
			});

			//发送信息
			function chat(){

				goEasy.publish({
				channel:'yujia',
				message: b.innerHTML
				});
				var w = b.innerHTML;
				$('#yujia').append("<br><span style='display: inline-block;height: 30px;line-height: 30px;background:#81D842;border:1px solid gray;border-radius: 5px;float: right;margin-top:10px;margin-right:10px;padding:3px;'>"+w+'</span><br>');


				$('#aaa').html("");
			}
</script>
	<!-- 头部结束	 -->

	<!-- 左边节点 -->
	<link rel="stylesheet" href="/static/fontawesome-5.5.0/css/all.css" />
<style type="text/css">
		dt .a{
			color:#BDBDBD;
			width: 20px;
			margin-left: -30px;
			margin-right: 20px;
			font-size: 18px;
		}
		dt .b{
			color:#BDBDBD;
			font-size: 18px;
			margin-left: 70px;
		}
</style>

<div class="container" style="margin-top:20px; ">
	<div class="leftsidebar_box">
		<dl class="system_log">
			<dt>
				<i class="fas fa-home a"></i>
					<a href="/admin/index/index">首&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;页</a>
			</dt>
		</dl>
		<!--用户管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-users  a"></i>
					用户管理
				<i class="fas fa-angle-down   b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a class="cks" href="/admin/user/userList">会员管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--用户管理结束-->
		<!--书籍管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-book-open a"></i>
					书籍管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a class="cks" href="/admin/sale/saleBookList">出售书籍</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a class="cks" href="/admin/inquiry/inquiryBookList">求购书籍</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--书籍管理结束-->
		<!--留言管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-comments a"></i>
					 留言管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/bcomment/commentList" class="cks">出售留言</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/scomment/commentList" class="cks">求购留言</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--留言管理结束-->
		<!--回复管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-reply a"></i>
					回复管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/breply/replyList" class="cks">留言回复</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--回复管理结束-->
		<!--订单管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-file-invoice-dollar a"></i>
					订单管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/order/orderList" class="cks">订单管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--订单管理结束-->
		<!-- 公告管理开始 -->
		<dl class="system_log">
			<dt>
				<i class="fas fa-bullhorn a"></i>
					 公告管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/notice/noticeList" class="cks">公告管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!-- 公告管理结束 -->
		<!-- 日志管理开始 -->
		<!-- <dl class="system_log">
			<dt>
				<i class="fas fa-file-invoice a"></i>
					日志管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/notice/noticeList" class="cks">日志管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl> -->
		<!-- 日志管理结束 -->
		<!-- 违规管理开始 -->
		<dl class="system_log">
			<dt>
				<i class="fas fa-skull-crossbones a"></i>
					违规管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/violate/violateList" class="cks">违规处理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!-- 违规管理结束 -->
	</div>
</div>
	<!--左边结点结束-->
	
	<!--main开始-->
	<div id="MainForm">
		<div class="form_boxA">
			<div class="a">
				<h2>淘书街-修改 <?php echo $user['user_realname']; ?> 基本信息</h2>
			</div>
			<form action="/admin/user/userUpdate" method="post" enctype="multipart/form-data" class="add_form" onsubmit="return checkEdit()" style="width: 700px;">
				<div style="float: left;">
				<input type="hidden" name="id" value="<?php echo $user['user_id']; ?>" />
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>学号：</label>
					<input type="text" name="" class="add_input" placeholder="输入12位学号" value="<?php echo $user['user_name']; ?>" disabled="true" />
					<input type="hidden" name="name" class="add_input" placeholder="输入12位学号" value="<?php echo $user['user_name']; ?>" />
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>性别：</label>
					<?php if($user['user_sex'] == '男'): ?>
					<input type="radio" value="男" name="sex" class="add_radio" checked /> 男
					<input type="radio" value="女" name="sex" class="add_radio"/> 女
					<?php else: ?>
					<input type="radio" value="男" name="sex" class="add_radio" /> 男
					<input type="radio" value="女" name="sex" class="add_radio" checked /> 女
					<?php endif; ?>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>真实姓名：</label>
					<input type="text" name="realname" class="add_input" placeholder="请输入真实姓名" value="<?php echo $user['user_realname']; ?>" onfocus="Real()" onblur="checkReal()" />
					<span class="tip" id="tip-realname">请输入真实姓名</span>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>联系方式：</label>
					<input type="text" name="tel" placeholder="输入联系方式" class="add_input" value="<?php echo $user['user_tel']; ?>" onfocus="Tel()" onblur="checkTel()"/>
					<span class="tip" id="tip-tel">请输入联系方式</span>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>地址：</label>
					<input type="text" name="addr" placeholder="输入详细地址" class="add_input" value="<?php echo $user['user_addr']; ?>" onfocus="Addr()" onblur="checkAddr()"/>
					<span class="tip" id="tip-addr">请输入详细地址</span>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>年级：</label>
					<select name="grade" class="add_input">
						<option value="2014" <?php if($user['grade'] == "2014") {echo "selected";} ?> >2014</option>
						<option value="2015" <?php if($user['grade'] == "2015") {echo "selected";} ?> >2015</option>
						<option value="2016" <?php if($user['grade'] == "2016") {echo "selected";} ?> >2016</option>
						<option value="2017" <?php if($user['grade'] == "2017") {echo "selected";} ?> >2017</option>
					</select>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>专业：</label>
					<select name="class" class="add_input">

						<?php if(is_array($classes) || $classes instanceof \think\Collection || $classes instanceof \think\Paginator): $i = 0; $__LIST__ = $classes;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$class): $mod = ($i % 2 );++$i;?>
							
							<option value="<?php echo $class['class_id']; ?>" <?php if ($class['class_id'] ==$user['class_id'] ) {echo "selected";} ?> ><?php echo $class['class_name']; ?></option>
						<?php endforeach; endif; else: echo "" ;endif; ?>
					</select>
				</div>
				<div class="add_list">
					<label class="add_label" style="margin-top: 30px;">个人说明：</label>
					<textarea name="content" class="add_textarea"><?php echo $user['user_content']; ?></textarea>
				</div>
				</div>
				<div class="user_right">
					<div class="img_icon" id="preview">
						<img src="<?php echo $user['user_img']; ?>" class="edituser_img" id="headImgBox"/>
					</div>
					<input type="file" name="img" style="margin: 30px 63px 0 40px;" onchange="uploadsimage(this);" />
					<input type="hidden" name="headImg" value="<?php echo $user['user_img']; ?>" id="headImg">
				</div>
				<input type="submit" value="修改" class="add_submit" style="margin-left: 300px;" />
			</form>
		</div>
	</div>
	<!--main结束-->
	
	</body>
</html>
<script>
	var user = document.getElementById("user");
	user.getElementsByClassName("icon1")[0].style.display = "block";
	user.getElementsByClassName("icon2")[0].style.display = "none";
	user.getElementsByClassName("icon3")[0].style.display = "block";
	user.getElementsByClassName("icon4")[0].style.display = "none";
	user.getElementsByClassName("icon5")[0].style.display = "block";
	user.getElementsByClassName("coin11")[0].style.display = "block";
	user.getElementsByClassName("coin22")[0].style.display = "none";
	user.getElementsByClassName("cks")[0].setAttribute("class", "menu_chioce2");
	user.getElementsByTagName("dd")[0].style.display = "block";
</script>

<script type="text/javascript">
//上传图片
function uploadsimage(obj) {
	if ( obj.value == "" ) return;

	var formdata = new FormData();

    formdata.append("image" , $(obj)[0].files[0]);//$(obj)[0].files[0]为文件对象

    $.ajax({
    	type : 'post',
    	url : '/admin/common/UserImage',
    	data : formdata,
    	cache : false,
        processData : false, // 不处理发送的数据，因为data值是Formdata对象，不需要对数据做处理
        contentType : false, // 不设置Content-type请求头
        success : function(ret){

        	$('#headImg').attr('value', ret);
 			$('#headImgBox').attr('src', ret);
        },
        error : function(){ 
        	alert('图片上传失败');
        }
    });
}

</script>