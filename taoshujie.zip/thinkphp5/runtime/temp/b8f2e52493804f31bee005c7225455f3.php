<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:73:"E:\shixun\thinkphp5\public/../application/index\view\sale\saledetail.html";i:1546524755;s:51:"../Application/index/view/common/common_header.html";i:1546528502;s:49:"../Application/index/view/common/common_foot.html";i:1544954783;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title><?php echo $ret['sale_name']; ?></title>
		<link rel="shortcut icon" href="../../../../static/img/shu.ico" />
		<link rel="stylesheet" href="../../../../static/css/front/sale_detail.css" />
		<link rel="stylesheet" href="../../../../static/css/front/common_top.css" />
		<link rel="stylesheet" href="../../../../static/css/front/tongxun.css" />
	</head>
	<body>
		<div class="q" id="q">
	<div class="top_content">
		<div class="welcome_txt">
			你好，欢迎来到淘书街！
		</div>
		<div class="right">
			请 <a href='/index/login/index' target="_blank">登录</a> 
			<a href='/index/register/index' style='color: #00CFBE; padding-left: 4px;' target="_blank">免费注册</a>
			<span class='shu'>|</span>
			<a href='/index/shopcar/index' target="_blank">购物车</a> <span class='shu'>|</span>
			<a href='/index/addsalebook/index' target="_blank">我要出售</a> <span class='shu'>|</span>
			<a href='/index/addinquirybook/index' target="_blank">我要求购</a> <span class='shu'>|</span>
			<a href='/admin/login/index' target="_blank">进入后台</a><span class='shu'>|</span><a style="display: inline-block;" onclick="show()">联系客服</a>
		</div>
	</div>
</div>
<div class="q" id="q1">
	<div class="top_content">
		<div class="welcome_txt">
			你好，欢迎来到淘书街！
		</div>
		<div class="right">
			<a href="/index/personalcenter/edit"><?php echo session('username');?></a> <span class='shu'>|</span>
			<a href='/index/shopcar/index'>购物车</a> <span class='shu'>|</span>
			<a href='/index/addsalebook/index' target="_blank">我要出售</a> <span class='shu'>|</span>
			<a href='/index/addinquirybook/index' target="_blank">我要求购</a> <span class='shu'>|</span>
			<a style="display: inline-block;cursor: pointer;" onclick="show()">联系客服</a><span class='shu'>|</span>
			<a href='/admin/login/index' target="_blank">进入后台</a>
			
		</div>
	</div>
</div>
<?php $a = session('username');if((!isset($a) || session('username')=='')): ?> 
<script type='text/javascript'>
	document.getElementById('q').style.display = 'block';
	document.getElementById('q1').style.display = 'none';
</script>

<?php else: ?>
<script type='text/javascript'>
	document.getElementById('q1').style.display = 'block';
	document.getElementById('q').style.display = 'none';
</script>
<?php endif; ?>
<div class="w">
	<!--头部-->
	<div class="top">
		<div class="logo">
			<a href="?"><img src="/static/img/taoshujie.png" /></a>
		</div>
		<form action="/index/search/searchsale" method="post" class="search" onsubmit="checkSearch();">
			<div class="search_div">
				<input type="text" placeholder="出售书籍名称" name="keyword" class="search_a"/>
				<input type="submit" class="search_b" value="搜索"></input>
			</div>
		</form>
	</div>
</div>
<!--导航栏-->
<div class="nav">
	<div class="nav_bar">
		<div class="all_type nav_active">
			全部图书分类
			<span class="all_type_a"></span>
		</div>
		<div class="nav_r">
			<ul id="nav_qa">
				<a href="/index/index/index"><li>首页</li></a>
				<a href="/index/type/showAllTypeSecond"><li>分类</li></a>
				<a href="/index/sale/showAllSaleBook"><li>出售</li></a>
				<a href="/index/inquire/showAllInquireBook"><li>求购</li></a>
			</ul>
		</div>
	</div>
</div>
<script type="text/javascript" src="../../../../static/js/front/jquery.min.js"></script>
<script type="text/javascript">
      //菜单栏的点击颜色切换
   	    var pn = location.pathname;
        var as = document.getElementById('nav_qa').getElementsByTagName("a");   
        for (var i = 0, j = as.length; i < j; i++){
           
            if(pn.length>3){
       
                if (as[i].href.indexOf(pn) != -1) {as[i].className = 'nav_active'; break; }
            }
        }
        if(pn.length<3){as[0].className = 'nav_active';}

        function show(){
        	$('#jstx').fadeIn();
        }
        function showno(){
        	$('#jstx').fadeIn();
        }

</script>

<!-- 实时通讯 -->
<div style="width: 500px;height: 490px;border: 2px solid #00C7B4;position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%); border-radius: 5px;padding:2px 0px;background: #FFF;z-index: 1200;display:none;" id="jstx">
		<div class="title-content">
			<div class="tao-img"><img src="../../../../static/img/taoshujie.png"></div>
			<div class="chat-close"><i class="fas fa-chevron-circle-down close" onclick="showno()"></i></div>
			<div class="chat-title">
				<div class="chat-text">
					<div class="chat-people">人工客服--小美</div>
					<div class="chat-mags">正在为您服务，请稍等</div>
				</div>
				<div class="chat-img"><img src="../../../../static/img/1.jpg"></div>
			</div>
		</div>
		<!-- 内容信息 -->
		<div style="width: 100%;height: 60%;overflow: hidden;overflow-y:scroll;background:#F5F5F5;" id="yujia">
			
		</div>
		<!-- 内容信息结束 -->
		<div class="send-content" >
			<!-- 表情 -->
			<div class="send-icon"><i class="far fa-grin-squint smile"  onclick="slideDownEmojiBox()"></i>
				<div id="emoji-box" >
					
					<div  class="cha" style="height: 28px">
						<span onclick="slideUpEmojiBox()">X</span>
					</div>
					<div style="height: 180px;overflow: hidden;overflow-y: scroll;">
						<?php $__FOR_START_9328__=1;$__FOR_END_9328__=132;for($i=$__FOR_START_9328__;$i < $__FOR_END_9328__;$i+=1){ ?>
						<img src="/static/img/qq/<?php echo $i; ?>.gif" style="margin: 5px" onclick="selectEmoji(this)">
						<?php } ?>
					</div>
				</div>
			
			</div>
			<!-- 表情结束 -->
			<div class="send-box" contenteditable="true" id="aaa"></div>
			<div class="send-button" onclick="chat()"><i class="fas fa-location-arrow sbutton"></i></div>
			
		</div>

	</div>

<script type="text/javascript" src="http://cdn.goeasy.io/goeasy.js"></script>
<script type="text/javascript" charset="UTF-8">
		var a = document.getElementById('aaa');
		var goEasy = new GoEasy({
		appkey: 'BC-beea5de574d04e92ba6e75553432fcfe'
		});
        
        function showno(){
        	$('#jstx').fadeOut();
        }

		
		goEasy.subscribe({
		channel:'yujia',
		onMessage: function(message){
			
			  	$('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;height:40px;background:#FFF;border-radius: 5px;margin-top:5px;margin-left:10px;padding:5px 10px;font-size:15px;line-height:30px;'>"+message.content+'</span></div>');
			
		}


		});
		//发送信息
		function chat(){

			goEasy.publish({
			channel:'yujialiang',
			message: a.innerHTML
			});
			var w = a.innerHTML;
			$('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;float:right;height:40px;background:#0cecd8;border-radius: 5px;margin-top:5px;margin-right:10px;padding:5px 10px;font-size:15px;line-height:30px;'>"+w+'</span></div>');

			$('#aaa').html("");
		}

		//选择表情
			function slideDownEmojiBox(){
				$('#emoji-box').slideDown();
			}
			function slideUpEmojiBox(){
				$('#emoji-box').slideUp();
			}
			function selectEmoji(obj){
				var img_src=$(obj).attr('src');
				var html="<img src='"+img_src+"'/>";
				$('#aaa').append(html);
				slideUpEmojiBox();
			}

		//滚动条
		function sc() 
		{ 
	    var e=document.getElementById("yujia");
	    if(e)
	        e.scrollTop=e.scrollHeight;          
		}
		$(document).ready(function(){
		//等加载完再运行
		    setInterval("sc()",10);

		});
</script>
<!-- 实时通讯 -->
		<div class="w">
			<div class="location">
				你现在的位置：
				<a href="/index/type/showAllTypeSecond">全部图书分类</a>
				<span>></span>
				<?php echo $ret['type_name']; ?>
				<span>></span>
				<a href="/index/sale/classdetail?second_name=<?php echo $ret['second_name']; ?>"><?php echo $ret['second_name']; ?></a>
			</div>
		</div>
		<div class="book_info">
			<div class="imgdiv">
				<!--<span></span>-->
				<img src="<?php echo $ret['sale_img']; ?>" />
			</div>
			<!--基本信息-->
			<div class="info">
				<div class="title"><?php echo $ret['sale_name']; ?></div>
				<div class="detail_info">
					<div class="info_left">
						<dd>ISBN：<span><?php echo $ret['sale_isbn']; ?></span></dd>
						<dd>库存：<span><?php echo $ret['sale_num']; ?></span></dd>
						<dd>作者：<span><?php echo $ret['sale_author']; ?></span></dd>
						<dd>出版社：<span><?php echo $ret['sale_publishing']; ?></span></dd>
					</div>
					<div class="info_right">
						<dd>页数：<span><?php echo $ret['sale_page']; ?></span></dd>
						<dd>新旧程度：<span><?php echo $ret['sale_degrees']; ?></span></dd>
						<dd>出售者：<span><?php echo $ret['user_realname']; ?></span></dd>
					</div>
				</div>
			</div>
			<!--价钱-->
			<div class="info2">
				<div class="price">
					现价：<span>￥<?php echo $ret['sale_afprice']; ?></span>
				</div>
				<div class="pre_price">
					原价：<span>￥<?php echo $ret['sale_beprice']; ?></span>
				</div>
			</div>
			<!--加购收藏按钮-->
			<div class="operation" id="o">
				<a href="/index/shopcar/insert?id=<?php echo $ret['sale_id']; ?>"><div class="collect">加入购物车</div></a>
				<a href="/index/ordersend/index?id=<?php echo $ret['sale_id']; ?>"><div class="buy">购买</div></a>
			</div>
		</div>
		<!--详细内容-->
		<div class="content_info">
			<div class="content_title">
				<span>内容简介</span>
			</div>
			<div class="content">
				<?php echo $ret['sale_content']; if( $ret['sale_content'] == null ){echo "无内容";} ?>	
			</div>
		</div>
		
		<div class="content_info">
			<div class="content_title">
				<span>书籍留言</span>
			</div>
			<div class="content">
				<div class="bcomment">
					<form action="/index/sale/postmsg" method="post" onsubmit="return checkComment();">
						<textarea cols="101" rows="7" name="content"></textarea>
						
						<input type="hidden" value="<?php echo $ret['sale_id']; ?>" name="book_id" />
						<input type="submit" value="发表留言" />
						<span>(限255字)</span>
					</form>
				</div>
				<div class="bc_detail">
					<ul>
						<?php foreach($res as $value): ?>
						<li>
							<div class="bcUser">
								<a href="/index/personalsalecenter/index?id=<?php echo $value['user_id']; ?>" target="_blank">
									<img src="<?php echo session('user_img'); ?>" />
								</a>
								<div class="name_txt">
									<a href="/index/personalsalecenter/index?id=<?php echo $value['user_id']; ?>" target="_blank">
										<?php 
											if($value['user_realname'] != null){
												echo $value['user_realname'];
											}
											else if($value['nickname'] != null){
												echo $value['nickname'];
											}
											else{
												echo $value['user_name'];
											}
										?>
										<!--<?php echo $value['user_realname']; ?>-->
									</a>
								</div>
							</div>
							<div class="bc_content">
								<?php echo $value['bcomment_content']; ?>
								<div class="bc_time"><?php echo date("Y-m-d h:m:s",$value['bcomment_time']); ?>
									<div style="width: 200px;height: 25px;float: right;">
										<a href="/index/sale/dianzan?ids=<?php echo $value['bcomment_id']; ?>">
											<img src="
											../../../../static/img/dianzan.png" style="margin-left:110px;width: 25px;"></a><font><?php echo $value['dzsum']; ?></font>
										<img src="../../../../static/img/pinlun.png" style="margin-left:20px;width: 23px;" onclick="show(<?php echo $value['bcomment_id']; ?>)">
									</div>
								</div>
								<!-- 回复评论内容 -->
								<div>

									<?php foreach($reply as $key => $vo): if($vo['comment_id']==$value['bcomment_id']): ?>
										<p><?php echo $vo['user_realname']; ?>：<?php echo $vo['reply_content']; ?>&nbsp;&nbsp;&nbsp;&nbsp;<font style="color: gray;font-size: 10px;"><?php echo date("Y-m-d H:m:s",$vo['addtime']); ?></font></p>
										<?php endif; endforeach; ?>
								</div>
							</div>
							<input type="hidden" value="" id="hiddenzhi">
						</li>
						<?php endforeach; if( empty($res) ){echo "没有留言";} ?>	
					</ul>
				</div>
			</div>
		</div>
		<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="../../../../static/css/front/common_foot.css" />
	</head>
	<body>
		<div class="foot">
			<div class="foot_a">
				<span>买卖二手书,正版旧书,大学教材,旧书,就上校园二手书籍交易网:淘书街。
					<br>做最专业的校园二手书籍交易网站,求购或出售二手书,方便你我他。</span>
			</div>
		</div>
	</body>
</html>

		<!-- 回复评论输入框开始 -->
		<div style="display:none;position: fixed;top:0px; width: 100%;height: 100%;background: rgba(0,0,0,0.4);z-index:900;" id="show_pinlundiv">
			<div style="position: absolute;top: 50%;left: 50%;background: #FFF;width: 500px;height: 350px;transform: translate(-50%,-50%);border-radius: 10px;z-index: 1000;">

				<div style="margin: 10px;">
					<span style="font-size: 15px; color: gray;" id="kuanzhi">回复评论</span><a onclick="noshow()" style="display: block;width: 20px;height: 20px;border:1px solid gray; border-radius: 30px;float: right;line-height: 20px;color: gray;font: 20px;cursor: pointer;"><center>X</center></a>
				</div>

				<div style="padding: 10px 20px;">

					<div style="width: 100%;height: 230px;border: 1px solid gray;" contenteditable="true" id="shuru"></div>
				  
				</div>
				
		 <input type="submit" name="submit" value="提交" style="background: green; width: 50px;height: 20px;margin-left:44%; " onclick="postdiv()">
	</div>
		</div>
		<!-- 回复评论输入框结束 -->
		<!-- 回复评论成功与失败 -->
		<div style="width: 200px;height: 100px;background: rgba(0,0,0,0.4);z-index: 1200;position:fixed;top: 50%;left: 50%;transform: translate(-50%,-50%); display:none; color: #FFF;font-size: 16px;line-height: 100px;text-align: center;" id="pinluncg">   </div>
		<!-- 回复评论成功与失败 -->
		<script type="text/javascript" src="../../../../static/js/front/common_top.js" ></script>
	<script src="../../../../static/js/front/jquery.min.js"></script>
	<script>
		function checkComment(){
			var content = document.getElementsByName("content")[0].value;
			if( content.length == 0 ){
				alert("留言不能为空！");
				return false;
			}
			else if(content.length > 255){
				alert("留言内容不能超过255字！");
				return false;
			}
			return true;
		}
		function show(obj){
 				$('#hiddenzhi').val(obj);
 				$('#show_pinlundiv').fadeIn();
 		}
 		function noshow(){
            $('#show_pinlundiv').fadeOut();
 		}

 		function postdiv(){

				var data = $('#shuru').html();
				var hiddenzhi = $('#hiddenzhi').val();

				$.post('/index/sale/pinlun',{'data':data,'hiddenzhi':hiddenzhi},
						function(ret){
							$('#pinluncg').html("");
							if (ret.code==0) {
								if (ret.data==1) {
								      windows.location.href = ret.url;
								}
							}

							noshow();  
							$('#pinluncg').fadeIn();
							$('#pinluncg').append(ret.msg);
							 
			  setTimeout(function(){
							  $('#pinluncg').fadeOut();
							  window.location.reload();
							 },1200);

							},'json'); 
					    $('#shuru').html("");
					 
		}

		function changeddz(obj){
				$.post('/index/sale/changeddz',{'bcomment_id':obj},
						function(ret){
							
							if (ret.code==0) {
								if (ret.data==1) {
								      windows.location.href = ret.url;
								}
							}

							
							 
			 

							},'json');
					   
					    window.location.reload();

		}
	</script>
	</body>
</html>
