<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:86:"F:\study\www\taoshujie\thinkphp5\public/../application/index\view\shopcar\shopcar.html";i:1546529043;s:51:"../Application/index/view/common/common_header.html";i:1546528502;s:49:"../Application/index/view/common/common_foot.html";i:1544954783;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>淘书街：我的购物车</title>
		<link rel="shortcut icon" href="../../../../static/img/shu.ico" />
		<link rel="stylesheet" href="../../../../static/css/front/common_top.css" />
		<link rel="stylesheet" href="../../../../static/css/front/shopCar.css" />
		<link rel="stylesheet" href="../../../../static/font/css/font-awesome.min.css" />
		<link rel="stylesheet" href="../../../../static/css/front/tongxun.css" />
	</head>
	<body>
		
		<div class="q" id="q">
	<div class="top_content">
		<div class="welcome_txt">
			你好，欢迎来到淘书街！
		</div>
		<div class="right">
			请 <a href='/index/login/index' target="_blank">登录</a> 
			<a href='/index/register/index' style='color: #00CFBE; padding-left: 4px;' target="_blank">免费注册</a>
			<span class='shu'>|</span>
			<a href='/index/shopcar/index' target="_blank">购物车</a> <span class='shu'>|</span>
			<a href='/index/addsalebook/index' target="_blank">我要出售</a> <span class='shu'>|</span>
			<a href='/index/addinquirybook/index' target="_blank">我要求购</a> <span class='shu'>|</span>
			<a href='/admin/login/index' target="_blank">进入后台</a><span class='shu'>|</span><a style="display: inline-block;" onclick="show()">联系客服</a>
		</div>
	</div>
</div>
<div class="q" id="q1">
	<div class="top_content">
		<div class="welcome_txt">
			你好，欢迎来到淘书街！
		</div>
		<div class="right">
			<a href="/index/personalcenter/edit"><?php echo session('username');?></a> <span class='shu'>|</span>
			<a href='/index/shopcar/index'>购物车</a> <span class='shu'>|</span>
			<a href='/index/addsalebook/index' target="_blank">我要出售</a> <span class='shu'>|</span>
			<a href='/index/addinquirybook/index' target="_blank">我要求购</a> <span class='shu'>|</span>
			<a style="display: inline-block;cursor: pointer;" onclick="show()">联系客服</a><span class='shu'>|</span>
			<a href='/admin/login/index' target="_blank">进入后台</a>
			
		</div>
	</div>
</div>
<?php $a = session('username');if((!isset($a) || session('username')=='')): ?> 
<script type='text/javascript'>
	document.getElementById('q').style.display = 'block';
	document.getElementById('q1').style.display = 'none';
</script>

<?php else: ?>
<script type='text/javascript'>
	document.getElementById('q1').style.display = 'block';
	document.getElementById('q').style.display = 'none';
</script>
<?php endif; ?>
<div class="w">
	<!--头部-->
	<div class="top">
		<div class="logo">
			<a href="?"><img src="/static/img/taoshujie.png" /></a>
		</div>
		<form action="/index/search/searchsale" method="post" class="search" onsubmit="checkSearch();">
			<div class="search_div">
				<input type="text" placeholder="出售书籍名称" name="keyword" class="search_a"/>
				<input type="submit" class="search_b" value="搜索"></input>
			</div>
		</form>
	</div>
</div>
<!--导航栏-->
<div class="nav">
	<div class="nav_bar">
		<div class="all_type nav_active">
			全部图书分类
			<span class="all_type_a"></span>
		</div>
		<div class="nav_r">
			<ul id="nav_qa">
				<a href="/index/index/index"><li>首页</li></a>
				<a href="/index/type/showAllTypeSecond"><li>分类</li></a>
				<a href="/index/sale/showAllSaleBook"><li>出售</li></a>
				<a href="/index/inquire/showAllInquireBook"><li>求购</li></a>
			</ul>
		</div>
	</div>
</div>
<script type="text/javascript" src="../../../../static/js/front/jquery.min.js"></script>
<script type="text/javascript">
      //菜单栏的点击颜色切换
   	    var pn = location.pathname;
        var as = document.getElementById('nav_qa').getElementsByTagName("a");   
        for (var i = 0, j = as.length; i < j; i++){
           
            if(pn.length>3){
       
                if (as[i].href.indexOf(pn) != -1) {as[i].className = 'nav_active'; break; }
            }
        }
        if(pn.length<3){as[0].className = 'nav_active';}

        function show(){
        	$('#jstx').fadeIn();
        }
        function showno(){
        	$('#jstx').fadeIn();
        }

</script>

<!-- 实时通讯 -->
<div style="width: 500px;height: 490px;border: 2px solid #00C7B4;position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%); border-radius: 5px;padding:2px 0px;background: #FFF;z-index: 1200;display:none;" id="jstx">
		<div class="title-content">
			<div class="tao-img"><img src="../../../../static/img/taoshujie.png"></div>
			<div class="chat-close"><i class="fas fa-chevron-circle-down close" onclick="showno()"></i></div>
			<div class="chat-title">
				<div class="chat-text">
					<div class="chat-people">人工客服--小美</div>
					<div class="chat-mags">正在为您服务，请稍等</div>
				</div>
				<div class="chat-img"><img src="../../../../static/img/1.jpg"></div>
			</div>
		</div>
		<!-- 内容信息 -->
		<div style="width: 100%;height: 60%;overflow: hidden;overflow-y:scroll;background:#F5F5F5;" id="yujia">
			
		</div>
		<!-- 内容信息结束 -->
		<div class="send-content" >
			<!-- 表情 -->
			<div class="send-icon"><i class="far fa-grin-squint smile"  onclick="slideDownEmojiBox()"></i>
				<div id="emoji-box" >
					
					<div  class="cha" style="height: 28px">
						<span onclick="slideUpEmojiBox()">X</span>
					</div>
					<div style="height: 180px;overflow: hidden;overflow-y: scroll;">
						<?php $__FOR_START_22648__=1;$__FOR_END_22648__=132;for($i=$__FOR_START_22648__;$i < $__FOR_END_22648__;$i+=1){ ?>
						<img src="/static/img/qq/<?php echo $i; ?>.gif" style="margin: 5px" onclick="selectEmoji(this)">
						<?php } ?>
					</div>
				</div>
			
			</div>
			<!-- 表情结束 -->
			<div class="send-box" contenteditable="true" id="aaa"></div>
			<div class="send-button" onclick="chat()"><i class="fas fa-location-arrow sbutton"></i></div>
			
		</div>

	</div>

<script type="text/javascript" src="http://cdn.goeasy.io/goeasy.js"></script>
<script type="text/javascript" charset="UTF-8">
		var a = document.getElementById('aaa');
		var goEasy = new GoEasy({
		appkey: 'BC-beea5de574d04e92ba6e75553432fcfe'
		});
        
        function showno(){
        	$('#jstx').fadeOut();
        }

		
		goEasy.subscribe({
		channel:'yujia',
		onMessage: function(message){
			
			  	$('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;height:40px;background:#FFF;border-radius: 5px;margin-top:5px;margin-left:10px;padding:5px 10px;font-size:15px;line-height:30px;'>"+message.content+'</span></div>');
			
		}


		});
		//发送信息
		function chat(){

			goEasy.publish({
			channel:'yujialiang',
			message: a.innerHTML
			});
			var w = a.innerHTML;
			$('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;float:right;height:40px;background:#0cecd8;border-radius: 5px;margin-top:5px;margin-right:10px;padding:5px 10px;font-size:15px;line-height:30px;'>"+w+'</span></div>');

			$('#aaa').html("");
		}

		//选择表情
			function slideDownEmojiBox(){
				$('#emoji-box').slideDown();
			}
			function slideUpEmojiBox(){
				$('#emoji-box').slideUp();
			}
			function selectEmoji(obj){
				var img_src=$(obj).attr('src');
				var html="<img src='"+img_src+"'/>";
				$('#aaa').append(html);
				slideUpEmojiBox();
			}

		//滚动条
		function sc() 
		{ 
	    var e=document.getElementById("yujia");
	    if(e)
	        e.scrollTop=e.scrollHeight;          
		}
		$(document).ready(function(){
		//等加载完再运行
		    setInterval("sc()",10);

		});
</script>
<!-- 实时通讯 -->
		
		<!--购物车-->
		<div class="shopcar">
			<div class="shopcar_title">我的购物车</div>
			<div class="shopcar_body">
				
				<table cellspacing="0">
					<thead>
						<th class="col1"><input type="checkbox" name="fullChoose" onclick="fullChecked(this)"></th>
						<th class="col2">书名</th>
						<th class="col3">卖家</th>
						<th class="col4">原价</th>
						<th class="col5">售价</th>
						<th class="col6">库存量</th>
						<th class="col7">购买数量</th>
						<th class="col8">小计</th>
						<th class="col9">操作</th>
					</thead>
					<tbody>
						<?php foreach($ret as $value): ?>
						<form name="myform" action="/index/shopcar/pay" method="post">
						<tr>
							<td class="col1"><input type="checkbox" name="ids[]" class="eachChoose" value="<?php echo $value['id']; ?>" onclick="eachChecked();"></td>
							<td class="col2" id="td2">
								<a href="/index/sale/saledetail?id=<?php echo $value['sale_id']; ?>"><img src="<?php echo $value['sale_img']; ?>" /></a>
								<a href="/index/sale/saledetail?id=<?php echo $value['sale_id'];?>" class="sale_name"><?php echo $value['sale_name']; ?></a>
							</td>
							<td class="col3">
								<a href="?c=user&a=showSaleUser&id=<?php echo $value['user_id']; ?>" target="_blank">

									<?php 

									if($value['user_realname'] == null)
									{echo $value['user_name'];} 
									else{echo $value['user_realname'];
									} 

									?>
									
								</a>
							</td>
							<td class="col4">￥<?php echo $value['sale_beprice']; ?></td>
							<td class="col5">￥<span><?php echo $value['sale_afprice']; ?></span></td>
							<td class="col6"><?php echo $value['sale_num']; ?></td>
							<td class="col7">
								<a href="/index/shopcar/sub?id=<?php echo $value['id'];?>" class="op" onclick="return sub(this)">-</a>
								<span><?php echo $value['book_num']; ?></span>
								<a href="/index/shopcar/add?id=<?php echo $value['id'];?>" class="op" onclick="return add(this)">+</a>
							</td>
							<td class="col8">￥<span><?php echo $value['sale_afprice']*$value['book_num'] ?></span></td>
							<td class="col9"><a href="/index/shopcar/delete?id=<?php echo $value['id']; ?>" class="del" onclick='return queren();'>
								<i class="fa fa-trash"></i>
							</a></td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<div class="count">
				 	<input type="submit" name="Submit" class="deleteChecked" value="删除选中" id="delBtn" disabled="disabled" onclick='return queren();'></input>
				 	<span class="countnum">已选书籍 <span class="num">0</span> 本</span>
				 	<span class="countmoney">合计(不含运费) : <span class="money">￥0</span> </span>
				 	<input type="submit" name="Submit" id="sumBtn" class="sum" value="结 算" disabled="disabled"></input>
				</div>
				</form>
			</div>
		</div>
		
		<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="../../../../static/css/front/common_foot.css" />
	</head>
	<body>
		<div class="foot">
			<div class="foot_a">
				<span>买卖二手书,正版旧书,大学教材,旧书,就上校园二手书籍交易网:淘书街。
					<br>做最专业的校园二手书籍交易网站,求购或出售二手书,方便你我他。</span>
			</div>
		</div>
	</body>
</html>

		
	</body>
	<script type="text/javascript" src="../../../../static/js/front/shopCar.js" ></script>
	<script type="text/javascript" src="../../../../static/js/front/common_top.js" ></script>
</html>
<script src="../../../../static/js/front/jquery.min.js"></script>
<script type="text/javascript">
	function queren(){
		return window.confirm("你确认要删除吗？");
	}
	function sub(obj){
		var span = obj.nextElementSibling; // 获取-按钮下一个兄弟
		var oldNum = parseInt(span.innerHTML); // 旧数据
	  	if(oldNum == 1){
	  		return window.confirm("你确认要删除吗？");
  		
	  	}
	}
	function add(obj){
		var span = obj.previousElementSibling; // 获取+按钮上一个兄弟
		var oldNum = parseInt(span.innerHTML); // 旧数据
		var col6 = obj.parentElement.previousElementSibling.innerHTML;
		if( oldNum >= col6 ){
			alert("库存量不足！");
			return false;
		}
		return true;
	}
</script>
