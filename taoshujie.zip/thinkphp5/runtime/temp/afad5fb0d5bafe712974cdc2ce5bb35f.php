<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:69:"E:\shixun\thinkphp5\public/../application/admin\view\index\index.html";i:1546428343;s:44:"../application/admin/view/common/header.html";i:1546479090;s:42:"../application/admin/view/common/menu.html";i:1546156729;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>淘书街后台管理首页</title>
	<link rel="shortcut icon" href="/static/img/shu.ico" />
	<link rel="stylesheet" href="/static/css/back/index.css" />
	<link rel="stylesheet" href="/static/css/back/common.css" />
	<link rel="stylesheet" href="/static/font/css/font-awesome.min.css" />
	<link rel="stylesheet" href="../../../../static/css/front/tongxun.css" />
	<script type="text/javascript" src="/static/js/back/jquery.min.js"></script>
	<script type="text/javascript" src="/static/js/back/public.js"></script>
</head>
<body>

	<!-- 头部	 -->
	<!-- 头部 -->
<div class="head">
	<div class="headL">
		<img class="headLogo" src="/static/img/admin_logo.png"/>
	</div>
	<div class="headR">
		<span style="margin-bottom: 8px;display: inline-block;">
			<!-- 日历 -->
			<SCRIPT type=text/javascript src="../../../js/back/clock.js"></SCRIPT>
			<!-- <SCRIPT type=text/javascript>showcal();</SCRIPT> -->
        </span>
        <br />
        <div class="head_op">
	    	<?php if(\think\Session::get('admin_id') == ''): ?>
	    	<a href="/admin/login/index" >【登录】</a>
	    	<?php else: ?>
	    	<span>欢迎你，</span>
	    	<a href="" >【<?php echo \think\Session::get('admin_name'); ?>】</a>
	    	<a href="/admin/login/logout" >【安全退出】</a>
	    	<?php endif; ?>
			<a href="/index/index/index">【回到前台】</a>
			<a style="display:inline-block;cursor: pointer;" onclick="show()">【客户服务】</a>
        </div>
	</div>
</div>
<!-- 实时通讯 -->
<div style="width: 500px;height: 490px;border: 2px solid #00C7B4;position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%); border-radius: 5px;padding:2px 0px;background: #FFF;z-index: 1200;display: none;" id="jstx">
		<div class="title-content">
			<div class="tao-img"><img src="../../../../static/img/taoshujie.png"></div>
			<div class="chat-close"><i class="fas fa-chevron-circle-down close" onclick="showno()"></i></div>
			<div class="chat-title">
				<div class="chat-text">
					<div class="chat-people">人工客服--小美</div>
					<div class="chat-mags">正在为您服务，请稍等</div>
				</div>
				<div class="chat-img"><img src="../../../../static/img/1.jpg"></div>
			</div>
		</div>
		<!-- 内容信息 -->
		<div style="width: 100%;height: 60%;overflow: hidden;overflow-y:scroll;background:#F5F5F5;" id="yujia">
			
		</div>
		<!-- 内容信息结束 -->
		<div class="send-content" >
			<!-- 表情 -->
			<div class="send-icon"><i class="far fa-grin-squint smile"  onclick="slideDownEmojiBox()"></i>
				<div id="emoji-box" >
					
					<div  class="cha" style="height: 28px">
						<span onclick="slideUpEmojiBox()">X</span>
					</div>
					<div style="height: 180px;overflow: hidden;overflow-y: scroll;">
						<?php $__FOR_START_16657__=1;$__FOR_END_16657__=132;for($i=$__FOR_START_16657__;$i < $__FOR_END_16657__;$i+=1){ ?>
						<img src="/static/img/qq/<?php echo $i; ?>.gif" style="margin: 5px" onclick="selectEmoji(this)">
						<?php } ?>
					</div>
				</div>
			
			</div>
			<!-- 表情结束 -->
			<div class="send-box" contenteditable="true" id="aaa"></div>
			<div class="send-button" onclick="chat()"><i class="fas fa-location-arrow sbutton"></i></div>
			
		</div>

	</div>
<script type="text/javascript" src="../../../../static/js/front/jquery.min.js"></script>
<script type="text/javascript" src="http://cdn.goeasy.io/goeasy.js"></script>
<script type="text/javascript">
			function show(){
				$('#jstx').fadeIn();
			}
			function showno(){
				$('#jstx').fadeOut();
			}
			var b = document.getElementById('aaa');
			var goEasy = new GoEasy({
			appkey: 'BC-beea5de574d04e92ba6e75553432fcfe'
			});

			var a = document.getElementById('yujia');
			goEasy.subscribe({
			channel:'yujialiang',
			onMessage: function(message){
				
			   $('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;height: 30px;line-height: 30px;background:#FFF;border-radius: 5px;margin-top:5px;margin-left:10px;padding:3px 10px;font-size:15px;'>"+message.content+'</span></div>');


				
			}
			});

			//发送信息
			function chat(){

				goEasy.publish({
				channel:'yujia',
				message: b.innerHTML
				});
				var w = b.innerHTML;
				$('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;float:right;height: 30px;line-height: 30px;background:#0cecd8;border-radius: 5px;margin-top:5px;margin-right:10px;padding:3px 10px;font-size:15px;'>"+w+'</span></div>');


				$('#aaa').html("");
			}

			//选择表情
			function slideDownEmojiBox(){
				$('#emoji-box').slideDown();
			}
			function slideUpEmojiBox(){
				$('#emoji-box').slideUp();
			}
			function selectEmoji(obj){
				var img_src=$(obj).attr('src');
				var html="<img src='"+img_src+"'/>";
				$('#aaa').append(html);
				slideUpEmojiBox();
			}

			//滚动条
			function sc() 
			{ 
			    var e=document.getElementById("yujia");
			    if(e)
			        e.scrollTop=e.scrollHeight;          
			}
			window.onload = function(){
			//等加载完再运行
			    setInterval("sc()",1000);
			}
</script>
	<!-- 头部结束	 -->

	<!-- 左边节点 -->
	<link rel="stylesheet" href="/static/fontawesome-5.5.0/css/all.css" />
<style type="text/css">
		dt .a{
			color:#BDBDBD;
			width: 20px;
			margin-left: -30px;
			margin-right: 20px;
			font-size: 18px;
		}
		dt .b{
			color:#BDBDBD;
			font-size: 18px;
			margin-left: 70px;
		}
</style>

<div class="container" style="margin-top:20px; ">
	<div class="leftsidebar_box">
		<dl class="system_log">
			<dt>
				<i class="fas fa-home a"></i>
					<a href="/admin/index/index">首&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;页</a>
			</dt>
		</dl>
		<!--用户管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-users  a"></i>
					用户管理
				<i class="fas fa-angle-down   b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a class="cks" href="/admin/user/userList">会员管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--用户管理结束-->
		<!--书籍管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-book-open a"></i>
					书籍管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a class="cks" href="/admin/sale/saleBookList">出售书籍</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a class="cks" href="/admin/inquiry/inquiryBookList">求购书籍</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--书籍管理结束-->
		<!--留言管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-comments a"></i>
					 留言管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/bcomment/commentList" class="cks">出售留言</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/scomment/commentList" class="cks">求购留言</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--留言管理结束-->
		<!--回复管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-reply a"></i>
					回复管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/breply/replyList" class="cks">留言回复</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--回复管理结束-->
		<!--订单管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-file-invoice-dollar a"></i>
					订单管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/order/orderList" class="cks">订单管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--订单管理结束-->
		<!-- 公告管理开始 -->
		<dl class="system_log">
			<dt>
				<i class="fas fa-bullhorn a"></i>
					 公告管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/notice/noticeList" class="cks">公告管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!-- 公告管理结束 -->
		<!-- 日志管理开始 -->
		<!-- <dl class="system_log">
			<dt>
				<i class="fas fa-file-invoice a"></i>
					日志管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/notice/noticeList" class="cks">日志管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl> -->
		<!-- 日志管理结束 -->
		<!-- 违规管理开始 -->
		<dl class="system_log">
			<dt>
				<i class="fas fa-skull-crossbones a"></i>
					违规管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/violate/violateList" class="cks">违规处理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!-- 违规管理结束 -->
	</div>
</div>
	<!--左边结点结束-->
	
	<!--main开始-->
	<table width="99%" border="0" cellspacing="0" cellpadding="0" id="main">
		<tr>
			<td colspan="2">
				<span class="time" style="color: black;">

					<?php if(\think\Session::get('admin_id') == ''): ?>
					<a href="/admin/login/index" class=""><i class="fa fa-plus-circle"></i> 登录</a>
					<?php else: ?>
					<span>管理员账号：<?php echo \think\Session::get('admin_name'); ?></span>&nbsp;&nbsp;
					<a href="" class=""><i class="fa fa-plus-circle"></i> 添加新管理员</a>
					<div class="top">
						<span class="left">您上次的登录时间： <?php echo \think\Session::get('lastLoginTime'); ?> &nbsp;&nbsp;&nbsp;&nbsp;如非您本人操作，请及时</span>
						<a href="/admin/admin/updatePwdPage" style="color: #538ec6;">【更改密码】</a>
					</div>
					<div class="sec">这是您第<span class="num"><?php echo \think\Session::get('count'); ?></span>次登录！</div>
					<?php endif; ?>
				</span>

			</td>
		</tr>
		<tr>
			<td align="left" valign="top" colspan="2">
				<div class="main-tit">服务器信息</div>
				<div class="main-con">
					服务器软件：Apache/2.4.27(Win64) PHP/5.6.31<br/>
					PHP版本：5.6.31<br/>
					MYSQL版本： 5.7.19, for Win64 (x86)<br/>
				</div>
			</td>
		</tr>
		<tr>
			<td colspan="2" align="left" valign="top">
				<div class="main-corpy">系统提示</div>
				<div class="main-order">1=>欢迎来到淘书街后台管理系统<br/>
					2=>强烈建议您将IE7以上版本或其他的浏览器
				</div>
			</td>
		</tr>
	</table>
	<!--main结束-->
	
</body>
</html>
