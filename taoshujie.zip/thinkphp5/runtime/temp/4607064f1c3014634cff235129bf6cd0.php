<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:82:"E:\shixun\thinkphp5\public/../application/index\view\search\searchinquiry_yes.html";i:1545959108;s:59:"../Application/index/view/common/inquiry_common_header.html";i:1545412070;s:49:"../Application/index/view/common/common_foot.html";i:1544954783;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>淘书街-检索：<?php echo $keyword; ?></title>
		<link rel="shortcut icon" href="../../../../static/img/shu.ico" />
		<link rel="stylesheet" href="../../../../static/css/front/common_top.css" />
		<link rel="stylesheet" href="../../../../static/css/front/search_no.css" />
		<link rel="stylesheet" href="../../../../static/css/front/search_yes.css" />
		<link rel="stylesheet" href="../../../../static/css/front/page.css" />
	</head>
	<body>
		
		<div class="q" id="q">
	<div class="top_content">
		<div class="welcome_txt">
			你好，欢迎来到淘书街！
		</div>
		<div class="right">
			请 <a href='/index/login/index' target="_blank">登录</a> 
			<a href='/index/register/index' style='color: #00CFBE; padding-left: 4px;' target="_blank">免费注册</a>
			<span class='shu'>|</span>
			<a href='/index/shopcar/index' target="_blank">购物车</a> <span class='shu'>|</span>
			<a href='/index/addsalebook/index' target="_blank">我要出售</a> <span class='shu'>|</span>
			<a href='/index/addinquirybook/index' target="_blank">我要求购</a> <span class='shu'>|</span>
			<a href='?p=back&c=admin&a=login' target="_blank">进入后台</a>
		</div>
	</div>
</div>
<div class="q" id="q1">
	<div class="top_content">
		<div class="welcome_txt">
			你好，欢迎来到淘书街！
		</div>
		<div class="right">
			<a href="/index/personalcenter/edit"><?php echo session('username');?></a> <span class='shu'>|</span>
			<a href='/index/shopcar/index'>购物车</a> <span class='shu'>|</span>
			<a href='/index/addsalebook/index' target="_blank">我要出售</a> <span class='shu'>|</span>
			<a href='/index/addinquirybook/index' target="_blank">我要求购</a> <span class='shu'>|</span>
			<a href='/admin/index/index' target="_blank">进入后台</a>
		</div>
	</div>
</div>
<?php $a = session('username');if((!isset($a) || session('username')=='')): ?> 
<script type='text/javascript'>
	document.getElementById('q').style.display = 'block';
	document.getElementById('q1').style.display = 'none';
</script>

<?php else: ?>
<script type='text/javascript'>
	document.getElementById('q1').style.display = 'block';
	document.getElementById('q').style.display = 'none';
</script>
<?php endif; ?>
<div class="w">
	<!--头部-->
	<div class="top">
		<div class="logo">
			<a href="?"><img src="/static/img/taoshujie.png" /></a>
		</div>
		<form action="/index/search/searchinquiry" method="post" class="search" onsubmit="checkSearch();">
			<div class="search_div">
				<input type="text" placeholder="求购书籍名称" name="keyword" class="search_a"/>
				<input type="submit" class="search_b" value="搜索"></input>
			</div>
		</form>
	</div>
</div>
<!--导航栏-->
<div class="nav">
	<div class="nav_bar">
		<div class="all_type nav_active">
			全部图书分类
			<span class="all_type_a"></span>
		</div>
		<div class="nav_r">
			<ul>
				<a href="/index/index/index"><li>首页</li></a>
				<a href="/index/type/showAllTypeSecond"><li>分类</li></a>
				<a href="/index/sale/showAllSaleBook"><li>出售</li></a>
				<a href="/index/inquire/showAllInquireBook"><li class="nav_active">求购</li></a>
			</ul>
		</div>
	</div>
</div>
		
		<div class="search_content">
			<div class="search_title">关键字：<?php echo $keyword; ?></div>
			<div class="search_yes">
				<div class="yes_info">
					<ul>
						<?php foreach($ret as $value): ?>
						<li>
							<div class="info_div">
								<div class="info_img">
									<a href="/index/inquire/inquirydetail?id=<?php echo $value['inquiry_id']; ?> " target="_blank">
										<img src="<?php echo $value['inquiry_img']; ?>" title="<?php echo $value['inquiry_name']; ?>" />
									</a>
								</div>
								<div class="info">
									<!--书名-->
									<div class="title">
										<a href="/index/inquire/inquirydetail?id=<?php echo $value['inquiry_id']; ?> " target="_blank">
											<?php $value['inquiry_name']=preg_replace("/($keyword)/i","<b style=\"color:#00a082\">\\1</b>",$value['inquiry_name']);?>
											<?php echo $value['inquiry_name']; ?>
										</a>
									</div>
									<!--具体信息-->
									<div class="more">
										<?php echo $value['inquiry_author']; ?>
										<span class="xie">/</span>
										<?php echo $value['inquiry_publishing']; ?>
										<span class="xie">/</span>
										<?php echo $value['inquiry_page']; ?>页
										<span class="xie">/</span>
										<?php echo $value['inquiry_degrees']; ?>
										<span class="xie">/</span>
										<span class="price">￥<?php echo $value['inquiry_minprice']; ?> ~ ￥<?php echo $value['inquiry_maxprice']; ?></span>
									</div>
									<!--内容详情-->
									<div class="summary">
										<?php $value['inquiry_content']=preg_replace("/($keyword)/i","<b style=\"color:#00a082\">\\1</b>",$value['inquiry_content']);?>
										<?php echo $value['inquiry_content']; ?>
									</div>
									<!--发布者-->
									<div class="owner">
										<span class="username"><?php echo $value['user_realname']; ?></span>
										<span class="dept"><?php echo $value['dept_name']; ?></span>
										<span class="class"><?php echo $value['class_name']; ?>(<?php echo $value['grade']; ?>级)</span>
									</div>
								</div>
							</div>
							
						</li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
		</div>
		
		<div class="page">
			<?php echo $ret->render(); ?>
		</div>
		
		<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="../../../../static/css/front/common_foot.css" />
	</head>
	<body>
		<div class="foot">
			<div class="foot_a">
				<span>买卖二手书,正版旧书,大学教材,旧书,就上校园二手书籍交易网:淘书街。
					<br>做最专业的校园二手书籍交易网站,求购或出售二手书,方便你我他。</span>
			</div>
		</div>
	</body>
</html>

		
	</body>
	<script type="text/javascript" src="../../../../static/js/front/common_top.js" ></script>
</html>
