<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:78:"E:\shixun\thinkphp5\public/../application/index\view\orderreceive\receive.html";i:1545665671;s:48:"../application/index/view/common/center_top.html";i:1545112582;s:53:"../application/index/view/common/center_leftmenu.html";i:1546481110;s:49:"../application/index/view/common/common_foot.html";i:1544954783;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>淘书街：我收到的订单</title>
		<link rel="shortcut icon" href="../../../../static/img/shu.ico" />
		<link rel="stylesheet" href="../../../../static/css/front/personal.css" />
		<link rel="stylesheet" href="../../../../static/css/front/personal_order.css" />
		<link rel="stylesheet" href="../../../../static/font/css/font-awesome.min.css" />
	</head>
	<body>
		 <div class="top">
			<div class="logo">
				<div class="img"><a href="?"><img src="../../../../static/img/taoshujie.png" /></a></div>
				<div class="txt"><?php echo session('username'); ?>-个人中心</div>
				<div class="right">
					<a href="/index/index/index">首页</a> <span class="shu">|</span>
					<a href="/index/sale/showAllSaleBook">出售</a> <span class="shu">|</span>
					<a href="/index/inquire/showAllInquireBook">求购</a>
				</div>
			</div>
		</div>
		 <div class="personal_info">
			<div class="menu">
				<div class="menu_title">个人设置</div>
				<ul>
					<li class="menu_li">
						<a href="/index/personalcenter/edit" class="menu_a" id="baseLink">基本信息</a>
					</li>
					<li class="menu_li">
						<a href="/index/updatepwd/index" class="menu_a" id="passwordLink">修改密码</a>
					</li>
				</ul>
				
				<div class="menu_title">订单</div>
				<ul>
					<li class="menu_li"><a href="/index/orderreceive/alist" class="menu_a" id="orderreceiveLink">收到的订单</a></li>
					<li class="menu_li"><a href="/index/personalorder/alist" class="menu_a" id="personalorderLink">我下的订单</a></li>
				</ul>
				
				<div class="menu_title">书籍</div>
				<ul>
					<li class="menu_li"><a href="/index/personalsale/index" class="menu_a" id="personalsaleLink">出售书籍</a></li>
					<li class="menu_li"><a href="/index/personalinquiry/index" class="menu_a" id="personalinquiryLink">求购书籍</a></li>
				</ul>
				
				<div class="menu_title">留言</div>
				<ul>
					<li class="menu_li"><a href="/index/personalbcomment/index" class="menu_a" id="personalbcommentLink">出售留言</a></li>
					<li class="menu_li"><a href="/index/personalscomment/index" class="menu_a" id="personalscommentLink">求购留言</a></li>
				</ul>
			</div>
			<script type="text/javascript" src="../../../../static/js/front/jquery.min.js"></script>
			<script type="text/javascript">
             $(document).ready(function() {
	var path = window.document.location.pathname;
	var arr = path.split("/");
	switch(arr[2]){
		case 'personalcenter':
			$("#baseLink").addClass('on')
			break;
		case 'updatepwd':
			$("#passwordLink").addClass('on')
			break;
		case 'orderreceive':
			$("#orderreceiveLink").addClass('on')
			break;
		case 'personalorder':
			$("#personalorderLink").addClass('on')
			break;
		case 'personalsale':
			$("#personalsaleLink").addClass('on')
			break;
		case 'personalinquiry':
			$("#personalinquiryLink").addClass('on')
			break;
		case 'personalbcomment':
			$("#personalbcommentLink").addClass('on')
			break;
		case 'personalscomment':
			$("#personalscommentLink").addClass('on')
			break;
	}
});
</script>

			
			<div class="menu_info" style="display: block;">
				<div class="menu_head">
					<ul><li>我收到的订单</li></ul>
				</div>
				<!--修改登录密码-->
				<div class="menu_detail" style="display: block;">
					<div class="order_top">
						<div class="a">订单详情</div>
						<div class="b">总金额</div>
						<div class="c">购买者</div>
						<div class="d">出售者</div>
						<div class="e">操作</div>
					</div>
					<ul>
						<?php foreach($ret as $vo): ?>
						<li class="order_li">
							<div class="order_head">
								<input type="checkbox" />
								<span class="order_time"><?php echo date('Y-m-d', strtotime($vo['create_time'])); ?></span>
								<span class="order_num">订单号：<?php echo $vo['order_id']; ?></span>
								
								<?php
								if($vo['order_state'] == 0){
								?>
								<span id="s1" style="float: right; margin-right: 10px; color: #00c7b4;">等待买家确认</span>
								<?php } 
								if($vo['order_state'] == 1){
								?>
								<span id="s2" style="float: right; margin-right: 10px;">交易成功</span>
								<?php } ?>
							</div>
							<div class="order_info">
								<div class="order_img">
									<a href="?c=saleBook&a=each&id=<?php echo $vo['sale_id']; ?>"><img src="<?php echo $vo['sale_img']; ?>" /></a>
								</div>
								<div class="order_name">
									<a href="?c=saleBook&a=each&id=<?php echo $vo['sale_id']; ?>"><?php echo $vo['sale_name']; ?></a>
								</div>
								<div class="order_price">
									<span class="be">￥<?php echo $vo['sale_beprice']; ?></span><br />
									<span class="af">￥<?php echo $vo['sale_afprice']; ?></span>
								</div>
								<div class="order_sum">×<?php echo $vo['order_sum']; ?></div>
								<div class="order_pay">￥<?php echo $vo['order_price']; ?></div>
								<div class="order_buy"><a href="?c=user&a=showSaleUser&id=<?php echo $vo['user_id']; ?>" target="_blank"><?php echo $vo['user_realname']; ?></a></div>
								<div class="order_sale"><?php echo session('username'); ?></div>
								<?php 
								if($vo['order_state'] == 1){
								?>
								<a href="?c=shoporder&a=delReceive&id=<?php echo $vo['order_id']; ?>" id="d1" onclick="return queren()"><i class="fa fa-trash"></i></a>
								<?php } ?>
							</div>
						</li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
		</div>
		 <!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="../../../../static/css/front/common_foot.css" />
	</head>
	<body>
		<div class="foot">
			<div class="foot_a">
				<span>买卖二手书,正版旧书,大学教材,旧书,就上校园二手书籍交易网:淘书街。
					<br>做最专业的校园二手书籍交易网站,求购或出售二手书,方便你我他。</span>
			</div>
		</div>
	</body>
</html>

	</body>
</html>
<script>
	function queren(){
		return window.confirm("你确认要删除吗？确认后不可恢复！");
	}
	function queren1(){
		return window.confirm("你确认要购买该书籍吗？确认后不可更改");
	}
</script>
