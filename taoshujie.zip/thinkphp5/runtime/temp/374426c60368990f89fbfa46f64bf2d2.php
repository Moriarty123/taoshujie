<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:87:"E:\shixun\thinkphp5\public/../application/index\view\addinquirybook\addInquiryBook.html";i:1545132163;s:49:"../Application/index/view/common/common_foot.html";i:1544954783;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>淘书街：添加求购书籍</title>
		<link rel="shortcut icon" href="../../../../static/img/shu.ico" />
		<link rel="stylesheet" href="../../../../static/css/front/personal.css" />
		<link rel="stylesheet" href="../../../../static/css/front/addSaleBook.css" />
		<link rel="stylesheet" href="../../../../static/font/css/font-awesome.min.css" />
	</head>
	<body>
		<div class="top">
			<div class="logo">
				<div class="img"><a href="?"><img src="../../../../static/img/taoshujie.png" /></a></div>
				<div class="txt"><?php echo session('username'); ?> - 添加求购</div>
				<div class="right">
					<a href="/index/index/index">首页</a> <span class="shu">|</span>
					<a href="/index/sale/showAllSaleBook">出售</a> <span class="shu">|</span>
					<a href="?c=inquiry&a=showAllInquiry">求购</a>
				</div>
			</div>
		</div>
		
		<div class="asb_content">
			<form action="?c=Inquiry&a=add" method="post" enctype="multipart/form-data" onsubmit="return checkAll1();">
				<div class="asb_list">
					<label style="letter-spacing: 0.12em;">ISBN号</label>
					<input type="text" placeholder="请输入10位或13位ISBN码" name="isbn" onfocus="Isbn()" onblur="checkIsbn()" />
				</div>
				<span class="xing">*</span><span class="alarm"></span>
				<div class="asb_list">
					<label style="letter-spacing: 1.67em;">书名</label>
					<input type="text" placeholder="请输入书名" name="name" onfocus="Name()" onblur="checkName()" />
				</div>
				<span class="xing">*</span><span class="alarm"></span>
				<div class="asb_list">
					<label style="letter-spacing: 1.67em;">作者</label>
					<input type="text" placeholder="多个作者用空格隔开" name="author" onfocus="Author()" onblur="checkAuthor()" />
				</div>
				<span class="xing">*</span><span class="alarm"></span>
				<div class="asb_list">
					<label style="letter-spacing: 0.4em;">出版社</label>
					<input type="text" placeholder="请输入出版社" name="publishing" onfocus="Publishing()" onblur="checkPublishing()" />
				</div>
				<span class="xing">*</span><span class="alarm"></span>
				<div class="asb_img">
					<label>封面图片</label>
					<input type="file" name="img" />
				</div>
				<!--<span class="xing">*</span>-->
				<div class="asb_list">
					<label style="letter-spacing: 0.4em;">最低价</label>
					<input type="text" placeholder="请输入大于等于零的数字" name="beprice" onfocus="Beprice()" onblur="checkBeprice()" />
				</div>
				<span class="xing">*</span><span class="alarm"></span>
				<div class="asb_list">
					<label style="letter-spacing: 0.4em;">最高价</label>
					<input type="text" placeholder="请输入大于等于零的数字" name="afprice" onfocus="Afprice()" onblur="checkAfprice()" />
				</div>
				<span class="xing">*</span><span class="alarm"></span>
				<div class="asb_list">
					<label style="letter-spacing: 1.67em;">数量</label>
					<input type="text" value="1" name="num" placeholder="请输入大于零的数字" onfocus="Num()" onblur="checkNum()"/>
				</div>
				<span class="xing">*</span><span class="alarm"></span>
				<div class="asb_list">
					<label style="letter-spacing: 1.67em;">页码</label>
					<input type="text" name="page" placeholder="请输入大于零的数字" onfocus="Page()" onblur="checkPage()"/>
				</div>
				<span class="xing">*</span><span class="alarm"></span>
				<div class="asb_list">
					<label>新旧程度</label>
					<select class="degrees" name="degrees" onfocus="Degrees()" onblur="checkDegrees()">
						<option value="0">---------请选择---------</option>
						<option value="全新">全新</option>
						<option value="九成新">九成新</option>
						<option value="八成新">八成新</option>
						<option value="七成新">七成新</option>
						<option value="六成新及以下">六成新及以下</option>
					</select>
				</div>
				<span class="xing">*</span><span class="alarm"></span>
				<div class="asb_list">
					<label>书籍分类</label>
					<select class="degrees" name="type" onfocus="Type()" onblur="checkType()">
						<option value="0">---------请选择---------</option>
						<?php foreach($ret as $vo): ?>
						<option value="<?php echo $vo['second_id']; ?>"><?php echo $vo['second_name']; ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<span class="xing">*</span><span class="alarm"></span>
				<div class="asb_list aa">
					<label class="bb">内容简介</label>
					<textarea cols="20" rows="2" class="asblist_content" name="content"></textarea>
				</div>
				<div class="asb_list aa aa1">
					<label class="bb">附加信息</label>
					<textarea cols="20" rows="2" class="asblist_content" name="attach" placeholder="限255字" onblur="checkAttach()"></textarea>
				</div>
				<input type="submit" class="asb_submit" value="发布" />
			</form>
		</div>
		
		<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="../../../../static/css/front/common_foot.css" />
	</head>
	<body>
		<div class="foot">
			<div class="foot_a">
				<span>买卖二手书,正版旧书,大学教材,旧书,就上校园二手书籍交易网:淘书街。
					<br>做最专业的校园二手书籍交易网站,求购或出售二手书,方便你我他。</span>
			</div>
		</div>
	</body>
</html>

	</body>
	<script type="text/javascript" src="../../../../static/js/front/addSaleBook.js" ></script>
</html>
