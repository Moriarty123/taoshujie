<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:77:"E:\shixun\thinkphp5\public/../application/index\view\updatepwd\updatepwd.html";i:1545021449;s:48:"../application/index/view/common/center_top.html";i:1545112582;s:53:"../application/index/view/common/center_leftmenu.html";i:1546481110;s:49:"../application/index/view/common/common_foot.html";i:1544954783;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>淘书街：修改登录密码</title>
		<link rel="stylesheet" href="../../../../static/css/front/personal.css" />
		<link rel="stylesheet" href="../../../../static/css/front/personal_center.css" />
		<link rel="stylesheet" href="../../../../static/font/css/font-awesome.min.css" />
		<link rel="shortcut icon" href="../../../../static/img/shu.ico" />
	</head>
	<body>
		
	
		
		 <div class="top">
			<div class="logo">
				<div class="img"><a href="?"><img src="../../../../static/img/taoshujie.png" /></a></div>
				<div class="txt"><?php echo session('username'); ?>-个人中心</div>
				<div class="right">
					<a href="/index/index/index">首页</a> <span class="shu">|</span>
					<a href="/index/sale/showAllSaleBook">出售</a> <span class="shu">|</span>
					<a href="/index/inquire/showAllInquireBook">求购</a>
				</div>
			</div>
		</div>
		 <div class="personal_info">
			<div class="menu">
				<div class="menu_title">个人设置</div>
				<ul>
					<li class="menu_li">
						<a href="/index/personalcenter/edit" class="menu_a" id="baseLink">基本信息</a>
					</li>
					<li class="menu_li">
						<a href="/index/updatepwd/index" class="menu_a" id="passwordLink">修改密码</a>
					</li>
				</ul>
				
				<div class="menu_title">订单</div>
				<ul>
					<li class="menu_li"><a href="/index/orderreceive/alist" class="menu_a" id="orderreceiveLink">收到的订单</a></li>
					<li class="menu_li"><a href="/index/personalorder/alist" class="menu_a" id="personalorderLink">我下的订单</a></li>
				</ul>
				
				<div class="menu_title">书籍</div>
				<ul>
					<li class="menu_li"><a href="/index/personalsale/index" class="menu_a" id="personalsaleLink">出售书籍</a></li>
					<li class="menu_li"><a href="/index/personalinquiry/index" class="menu_a" id="personalinquiryLink">求购书籍</a></li>
				</ul>
				
				<div class="menu_title">留言</div>
				<ul>
					<li class="menu_li"><a href="/index/personalbcomment/index" class="menu_a" id="personalbcommentLink">出售留言</a></li>
					<li class="menu_li"><a href="/index/personalscomment/index" class="menu_a" id="personalscommentLink">求购留言</a></li>
				</ul>
			</div>
			<script type="text/javascript" src="../../../../static/js/front/jquery.min.js"></script>
			<script type="text/javascript">
             $(document).ready(function() {
	var path = window.document.location.pathname;
	var arr = path.split("/");
	switch(arr[2]){
		case 'personalcenter':
			$("#baseLink").addClass('on')
			break;
		case 'updatepwd':
			$("#passwordLink").addClass('on')
			break;
		case 'orderreceive':
			$("#orderreceiveLink").addClass('on')
			break;
		case 'personalorder':
			$("#personalorderLink").addClass('on')
			break;
		case 'personalsale':
			$("#personalsaleLink").addClass('on')
			break;
		case 'personalinquiry':
			$("#personalinquiryLink").addClass('on')
			break;
		case 'personalbcomment':
			$("#personalbcommentLink").addClass('on')
			break;
		case 'personalscomment':
			$("#personalscommentLink").addClass('on')
			break;
	}
});
</script>

			
			<div class="menu_info" style="display: block;">
				<div class="menu_head">
					<ul><li>修改登录密码</li></ul>
				</div>
				<!--修改登录密码-->
				<div class="menu_detail" style="display: block;">
					<form action="/index/updatepwd/updatepwd" method="post" onsubmit="return checkAll();">
						<input type="hidden" name="id" />
						<div class="menu_list">
							<label class="title">原始密码</label>
							<input type="password" class="content" name="prepwd" onblur="checkPre();" onfocus="Pre();"/>
						</div>
						<div class="msg" id="prePwd"></div>
						
						<div class="menu_list">
							<label class="title">设置密码</label>
							<input type="password" class="content" name="newPwd" onblur="checkNew();" onfocus="New();" />
						</div>
						<div class="msg" id="newPwd"></div>
						
						<div class="menu_list">
							<label class="title">确认密码</label>
							<input type="password" class="content" name="rePwd" onblur="checkRe();" onfocus="Re();" />
						</div>
						<div class="msg" id="rePwd"></div>
						
						<input type="submit" class="button" value="修改"></input>
					</form>
				</div>
			</div>
		</div>
		   <!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="../../../../static/css/front/common_foot.css" />
	</head>
	<body>
		<div class="foot">
			<div class="foot_a">
				<span>买卖二手书,正版旧书,大学教材,旧书,就上校园二手书籍交易网:淘书街。
					<br>做最专业的校园二手书籍交易网站,求购或出售二手书,方便你我他。</span>
			</div>
		</div>
	</body>
</html>

	</body>
</html>
<script type="text/javascript" src="../../../../static/js/front/personal_updatePwd.js" ></script>
