<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:69:"E:\shixun\thinkphp5\public/../application/admin\view\login\login.html";i:1545557203;}*/ ?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>登录</title>
<link rel="stylesheet" type="text/css" href="/static/css/back/login.css" />
</head>
<body>

	<!-- 登录body -->
	<div class="logDiv">
		<img class="logBanner" src="/static/img/logBanner.png" />
		<div class="logGet">
			<!-- 头部提示信息 -->
			<div class="logD logDtip">
				<p class="p1">登录</p>
			</div>
			<!-- 输入框 -->
			<form action="/admin/login/login" method="post" >
				<div class="lgD">
					<img class="img1" src="/static/img/logName.png" />
					<input type="text" placeholder="输入用户名" name="name" />
				</div>
				<div class="lgD">
					<img class="img1" src="/static/img/logPwd.png" />
					<input type="password" placeholder="输入密码" name="pwd" />
				</div>
				<span style="margin-left: 25px;">测试用户：admin 密码：admin</span>
				<div class="logC">
					<input type="submit" value="登录" />
				</div>
			</form>
		</div>
	</div>
	<!-- 登录body  end -->
	


</body>
</html>