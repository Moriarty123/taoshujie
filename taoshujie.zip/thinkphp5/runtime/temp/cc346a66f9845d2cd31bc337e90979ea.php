<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:75:"E:\shixun\thinkphp5\public/../application/admin\view\sale\saleBookEdit.html";i:1546156729;s:44:"../application/admin/view/common/header.html";i:1546479090;s:42:"../application/admin/view/common/menu.html";i:1546156729;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>淘书街修改出售信息</title>
		<link rel="shortcut icon" href="/static/img/shu.ico" />
		<link rel="stylesheet" href="/static/css/back/user.css" />
		<link rel="stylesheet" href="/static/css/back/common.css" />
		<link rel="stylesheet" href="/static/css/back/add.css" />
		<link rel="stylesheet" href="/static/css/back/edit.css" />
		
		<script type="text/javascript" src="/static/js/back/jquery.min.js"></script>
		<script type="text/javascript" src="/static/js/back/public.js"></script>
		<script type="text/javascript" src="/static/js/back/editSale.js"></script>
		<script type="text/javascript" src="/static/js/back/showImg.js"></script>
	</head>
	<body>
	<!-- 头部	 -->
	<!-- 头部 -->
<div class="head">
	<div class="headL">
		<img class="headLogo" src="/static/img/admin_logo.png"/>
	</div>
	<div class="headR">
		<span style="margin-bottom: 8px;display: inline-block;">
			<!-- 日历 -->
			<SCRIPT type=text/javascript src="../../../js/back/clock.js"></SCRIPT>
			<!-- <SCRIPT type=text/javascript>showcal();</SCRIPT> -->
        </span>
        <br />
        <div class="head_op">
	    	<?php if(\think\Session::get('admin_id') == ''): ?>
	    	<a href="/admin/login/index" >【登录】</a>
	    	<?php else: ?>
	    	<span>欢迎你，</span>
	    	<a href="" >【<?php echo \think\Session::get('admin_name'); ?>】</a>
	    	<a href="/admin/login/logout" >【安全退出】</a>
	    	<?php endif; ?>
			<a href="/index/index/index">【回到前台】</a>
			<a style="display:inline-block;cursor: pointer;" onclick="show()">【客户服务】</a>
        </div>
	</div>
</div>
<!-- 实时通讯 -->
<div style="width: 500px;height: 490px;border: 2px solid #00C7B4;position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%); border-radius: 5px;padding:2px 0px;background: #FFF;z-index: 1200;display: none;" id="jstx">
		<div class="title-content">
			<div class="tao-img"><img src="../../../../static/img/taoshujie.png"></div>
			<div class="chat-close"><i class="fas fa-chevron-circle-down close" onclick="showno()"></i></div>
			<div class="chat-title">
				<div class="chat-text">
					<div class="chat-people">人工客服--小美</div>
					<div class="chat-mags">正在为您服务，请稍等</div>
				</div>
				<div class="chat-img"><img src="../../../../static/img/1.jpg"></div>
			</div>
		</div>
		<!-- 内容信息 -->
		<div style="width: 100%;height: 60%;overflow: hidden;overflow-y:scroll;background:#F5F5F5;" id="yujia">
			
		</div>
		<!-- 内容信息结束 -->
		<div class="send-content" >
			<!-- 表情 -->
			<div class="send-icon"><i class="far fa-grin-squint smile"  onclick="slideDownEmojiBox()"></i>
				<div id="emoji-box" >
					
					<div  class="cha" style="height: 28px">
						<span onclick="slideUpEmojiBox()">X</span>
					</div>
					<div style="height: 180px;overflow: hidden;overflow-y: scroll;">
						<?php $__FOR_START_22456__=1;$__FOR_END_22456__=132;for($i=$__FOR_START_22456__;$i < $__FOR_END_22456__;$i+=1){ ?>
						<img src="/static/img/qq/<?php echo $i; ?>.gif" style="margin: 5px" onclick="selectEmoji(this)">
						<?php } ?>
					</div>
				</div>
			
			</div>
			<!-- 表情结束 -->
			<div class="send-box" contenteditable="true" id="aaa"></div>
			<div class="send-button" onclick="chat()"><i class="fas fa-location-arrow sbutton"></i></div>
			
		</div>

	</div>
<script type="text/javascript" src="../../../../static/js/front/jquery.min.js"></script>
<script type="text/javascript" src="http://cdn.goeasy.io/goeasy.js"></script>
<script type="text/javascript">
			function show(){
				$('#jstx').fadeIn();
			}
			function showno(){
				$('#jstx').fadeOut();
			}
			var b = document.getElementById('aaa');
			var goEasy = new GoEasy({
			appkey: 'BC-beea5de574d04e92ba6e75553432fcfe'
			});

			var a = document.getElementById('yujia');
			goEasy.subscribe({
			channel:'yujialiang',
			onMessage: function(message){
				
			   $('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;height: 30px;line-height: 30px;background:#FFF;border-radius: 5px;margin-top:5px;margin-left:10px;padding:3px 10px;font-size:15px;'>"+message.content+'</span></div>');


				
			}
			});

			//发送信息
			function chat(){

				goEasy.publish({
				channel:'yujia',
				message: b.innerHTML
				});
				var w = b.innerHTML;
				$('#yujia').append("<div style='width:100%;height:50px;'><span style='display: inline-block;float:right;height: 30px;line-height: 30px;background:#0cecd8;border-radius: 5px;margin-top:5px;margin-right:10px;padding:3px 10px;font-size:15px;'>"+w+'</span></div>');


				$('#aaa').html("");
			}

			//选择表情
			function slideDownEmojiBox(){
				$('#emoji-box').slideDown();
			}
			function slideUpEmojiBox(){
				$('#emoji-box').slideUp();
			}
			function selectEmoji(obj){
				var img_src=$(obj).attr('src');
				var html="<img src='"+img_src+"'/>";
				$('#aaa').append(html);
				slideUpEmojiBox();
			}

			//滚动条
			function sc() 
			{ 
			    var e=document.getElementById("yujia");
			    if(e)
			        e.scrollTop=e.scrollHeight;          
			}
			window.onload = function(){
			//等加载完再运行
			    setInterval("sc()",1000);
			}
</script>
	<!-- 头部结束	 -->

	<!-- 左边节点 -->
	<link rel="stylesheet" href="/static/fontawesome-5.5.0/css/all.css" />
<style type="text/css">
		dt .a{
			color:#BDBDBD;
			width: 20px;
			margin-left: -30px;
			margin-right: 20px;
			font-size: 18px;
		}
		dt .b{
			color:#BDBDBD;
			font-size: 18px;
			margin-left: 70px;
		}
</style>

<div class="container" style="margin-top:20px; ">
	<div class="leftsidebar_box">
		<dl class="system_log">
			<dt>
				<i class="fas fa-home a"></i>
					<a href="/admin/index/index">首&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;页</a>
			</dt>
		</dl>
		<!--用户管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-users  a"></i>
					用户管理
				<i class="fas fa-angle-down   b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a class="cks" href="/admin/user/userList">会员管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--用户管理结束-->
		<!--书籍管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-book-open a"></i>
					书籍管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a class="cks" href="/admin/sale/saleBookList">出售书籍</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a class="cks" href="/admin/inquiry/inquiryBookList">求购书籍</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--书籍管理结束-->
		<!--留言管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-comments a"></i>
					 留言管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/bcomment/commentList" class="cks">出售留言</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/scomment/commentList" class="cks">求购留言</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--留言管理结束-->
		<!--回复管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-reply a"></i>
					回复管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/breply/replyList" class="cks">留言回复</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--回复管理结束-->
		<!--订单管理开始-->
		<dl class="system_log">
			<dt>
				<i class="fas fa-file-invoice-dollar a"></i>
					订单管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/order/orderList" class="cks">订单管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!--订单管理结束-->
		<!-- 公告管理开始 -->
		<dl class="system_log">
			<dt>
				<i class="fas fa-bullhorn a"></i>
					 公告管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/notice/noticeList" class="cks">公告管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!-- 公告管理结束 -->
		<!-- 日志管理开始 -->
		<!-- <dl class="system_log">
			<dt>
				<i class="fas fa-file-invoice a"></i>
					日志管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/notice/noticeList" class="cks">日志管理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl> -->
		<!-- 日志管理结束 -->
		<!-- 违规管理开始 -->
		<dl class="system_log">
			<dt>
				<i class="fas fa-skull-crossbones a"></i>
					违规管理
				<i class="fas fa-angle-down b"></i>
			</dt>
			<dd>
				<img class="coin11" src="/static/img/coin111.png" />
				<img class="coin22" src="/static/img/coin222.png" />
				<a href="/admin/violate/violateList" class="cks">违规处理</a>
				<img class="icon5" src="/static/img/coin21.png" />
			</dd>
		</dl>
		<!-- 违规管理结束 -->
	</div>
</div>
	<!--左边结点结束-->
	
	<!--main开始-->
	<div id="MainForm">
		<div class="form_boxA">
			<div class="a">
				<h2>淘书街-修改 <?php echo $edit['sale_name']; ?> 基本信息</h2>
			</div>
			<form action="/admin/sale/saleBookEdit" method="post" enctype="multipart/form-data" class="add_form" onsubmit="return checkSale()" style="width: 700px;">
				<div style="float: left;">
				<input type="hidden" name="id" value="<?php echo $edit['sale_id']; ?>" />
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>ISBN：</label>
					<input type="text" name="showisbn" placeholder="请输入10位或13位ISBN码" value="<?php echo $edit['sale_isbn']; ?>" class="add_input" onfocus="Isbn()" onblur="checkISBN()" disabled="true"/>
					<input type="hidden" value="<?php echo $edit['sale_isbn']; ?>" name="isbn">
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>书名：</label>
					<input type="text" name="name" placeholder="请输入书名" class="add_input" value="<?php echo $edit['sale_name']; ?>" onfocus="Name()" onblur="checkName()"/>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>作者：</label>
					<input type="text" name="author" placeholder="多个作者可用空格隔开" value="<?php echo $edit['sale_author']; ?>" class="add_input" onfocus="Author()" onblur="checkAuthor()"/>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>出版社：</label>
					<input type="text" name="publishing" placeholder="请输入出版社" value="<?php echo $edit['sale_publishing']; ?>" class="add_input" onfocus="Publishing()" onblur="checkPublishing()" />
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>原价：</label>
					<input type="text" name="beprice" placeholder="请输入大于等于0的数字" value="<?php echo $edit['sale_beprice']; ?>" class="add_input" onfocus="Beprice()" onblur="checkBeprice()"/>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>售价：</label>
					<input type="text" name="afprice" placeholder="请输入大于等于0的数字" value="<?php echo $edit['sale_afprice']; ?>" class="add_input" onfocus="Afprice()" onblur="checkAfprice()"/>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>数量：</label>
					<input type="text" name="num" placeholder="大于0的数字" value="<?php echo $edit['sale_num']; ?>" class="add_input" onfocus="Num()" onblur="checkNum()"/>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>书籍页码：</label>
					<input type="text" name="page" placeholder="请输入大于0的数字" value="<?php echo $edit['sale_page']; ?>" class="add_input" onfocus="Page()" onblur="checkPage()"/>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>新旧程度：</label>
					<select class="add_input" name="degrees">
						<option value="全新" <?php if($edit['sale_degrees'] == "全新") {echo "selected";} ?> >全新</option>
						<option value="九成新" <?php if($edit['sale_degrees'] == "九成新") {echo "selected";} ?> >九成新</option>
						<option value="八成新" <?php if($edit['sale_degrees'] == "八成新") {echo "selected";} ?> >八成新</option>
						<option value="七成新" <?php if($edit['sale_degrees'] == "七成新") {echo "selected";} ?> >七成新</option>
						<option value="六成新及以下" <?php if($edit['sale_degrees'] == "六成新及以下") {echo "selected";} ?> >六成新及以下</option>
					</select>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>书籍分类：</label>
					<select class="add_input" name="type">
						<?php foreach($typeSecond as $key => $value){ ?>
						<option value="<?php echo $value['second_id']; ?>"><?php echo $value['second_name']; ?></option>
						<?php } ?>
					</select>
				</div>
				<div class="add_list">
					<label class="add_label"><span class="xing">*</span>出售人：</label>
					<select class="add_input" name="user">
						<?php foreach($users as $key => $value){ ?>
						<option value="<?php echo $value['user_id']; ?>"><?php echo $value['user_realname']; ?></option>
						<?php } ?>
					</select>
				</div>
				<div class="add_list">
					<label class="add_label" style="margin-top: 30px;">内容简介：</label>
					<textarea name="content" class="add_textarea"><?php echo $edit['sale_content']; ?></textarea>
				</div>
				</div>
				<div class="sale_right">
					<div class="img_icon" ><img src="<?php echo $edit['sale_img']; ?>" class="editSale_img" id="imgBox"/></div>
					<input type="file" name="selectImg" style="margin: 30px 63px 0 0px;" onchange="uploadsimage(this);" />
					<input type="hidden" id="img" name="img" src="<?php echo $edit['sale_img']; ?>" value="<?php echo $edit['sale_img']; ?>">
				</div>
				<input type="submit" value="修改" class="add_submit" style="margin-left: 300px;" />
			</form>
		</div>
	</div>
	<!--main结束-->
	
	</body>
</html>
<script>
	var user = document.getElementById("user");
	user.getElementsByClassName("icon1")[0].style.display = "block";
	user.getElementsByClassName("icon2")[0].style.display = "none";
	user.getElementsByClassName("icon3")[0].style.display = "block";
	user.getElementsByClassName("icon4")[0].style.display = "none";
	user.getElementsByClassName("icon5")[0].style.display = "block";
	user.getElementsByClassName("coin11")[0].style.display = "block";
	user.getElementsByClassName("coin22")[0].style.display = "none";
	
	user.getElementsByTagName("dd")[1].style.display = "block";
	
	user.getElementsByClassName("cks")[0].setAttribute("class", "menu_chioce2");
	user.getElementsByTagName("dd")[0].style.display = "block";
</script>

<script type="text/javascript">
//上传图片
function uploadsimage(obj) {
	if ( obj.value == "" ) return;

	var formdata = new FormData();

    formdata.append("image" , $(obj)[0].files[0]);//$(obj)[0].files[0]为文件对象
    formdata.append("path" , "sale");

    $.ajax({
    	type : 'post',
    	url : '/admin/common/UploadsImage',
    	data : formdata,
    	cache : false,
        processData : false, // 不处理发送的数据，因为data值是Formdata对象，不需要对数据做处理
        contentType : false, // 不设置Content-type请求头
        success : function(ret){

        	$('#img').attr('value', ret);
 			$('#imgBox').attr('src', ret);
        },
        error : function(){ 
        	alert('图片上传失败');
        }
    });
}

</script>