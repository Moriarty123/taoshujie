<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:69:"E:\shixun\thinkphp5\public/../application/index\view\login\index.html";i:1546335927;s:49:"../application/index/view/common/common_foot.html";i:1544954783;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>淘书街用户登录</title>
		<link rel="shortcut icon" href="../../../../static/img/shu.ico" />
		<link rel="stylesheet" href="../../../../static/css/front/register.css" />
		<link rel="stylesheet" href="../../../../static/font/css/font-awesome.min.css" />
	</head>
	<body>
		<div class="top">
			<div class="logo">
				<div class="img"><a href="?"><img src="../../../../static/img/taoshujie.png" /></a></div>
				<div class="txt">淘书街-用户登录</div>
				<div class="right">没有账号？ <a href="/index/register/index">立即注册</a></div>
			</div>
		</div>
		<div class="form">
			<form action="/index/login/login" method="post" onsubmit="return checkAll();">
				<div class="form_item">
					<label style="letter-spacing: 0.36em;">用户名</label>
					<input type="text" id="username" name="username" onblur="checkName();" onfocus="alertName();" />
				</div>
				<div class="form_alert" id="usermsg"></div>
				
				<div class="form_item">
					<label  style="letter-spacing: 1.33em;">密码</label>
					<input type="password" id="password" name="password" onblur="checkPwd();" onfocus="alertPwd();" />
				</div>
				<div class="form_alert" id="pwdmsg"></div>
				
				<div class="form_item">
					<label style="letter-spacing: 0.36em;">验证码</label>
					<input type="text" class="code_input" id="code" onblur="confirmCode();" onfocus="alertCode();"/>
					<button type="button" class="code" id="codeImg" onclick="createCode();"></button>
				</div>
				<div class="form_alert" id="codemsg"></div>
				
				<input type="submit" value="登录" class="submit_input"/>
			</form>
		</div>
		
			 <!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="../../../../static/css/front/common_foot.css" />
	</head>
	<body>
		<div class="foot">
			<div class="foot_a">
				<span>买卖二手书,正版旧书,大学教材,旧书,就上校园二手书籍交易网:淘书街。
					<br>做最专业的校园二手书籍交易网站,求购或出售二手书,方便你我他。</span>
			</div>
		</div>
	</body>
</html>

			 <!-- 封号警告框开始 -->
			 <div style="display:none;position: fixed;top:0px; width: 100%;height: 100%;background: rgba(0,0,0,0.4);z-index:900;" id="show_pinlundiv">
			 <div style="position: absolute;top: 50%;left: 50%;background: #FFF;width: 500px;height: 350px;transform: translate(-50%,-50%);border-radius: 10px;z-index: 1000;border: 3px solid #00C7B4;">
			 	<span style="display: block;margin-top: 100px;margin-left:15px;">
			 		<font style="color: #00c7b4;font-size: 25px;"><strong>对不起，此账号涉嫌违规，已被封号处理！</strong></font>
			 	</span>
			 	<div style="width: 165px;height: 25px;position: absolute;top:300px;left: 208px;">
			 	<button style="background: #00C7B4;width: 90px;height:30px;color:#FFF;cursor: pointer;" onclick="noshow()">确定</button>
			 		</div>
			 	<div>
			 </div>
			 <!-- 封号警告框结束 -->
		
	</body>
	<script type="text/javascript" src="../../../../static/js/front/login.js" ></script>	<script src="../../../../static/js/front/jquery.min.js"></script>
	<script type="text/javascript">
		function show(){
			$('#show_pinlundiv').fadeIn();
		}
		function noshow(){
			$('#show_pinlundiv').fadeOut();
		}

	
			if (<?php echo $Sensitivewords ?>) {
				show();
				}
	</script>
</html>
